/**
 * Dashboard Application - Academic Social Platform
 * @author Academicoapp Team
 * @version 2.0.0
 */

const DashboardApp = (function() {
  'use strict';

  // Application State
  const state = {
    user: {
      id: 1,
      name: 'Novais',
      avatar: 'img/nov.jpg',
      role: 'Professor',
      institution: 'ITEL',
      subject: 'Matemática'
    },
    theme: localStorage.getItem('dashboard-theme') || 'light',
    notifications: [],
    posts: [],
    isLoading: false,
    chatOpen: false
  };

  // DOM Elements Cache
  const elements = {};

  // Configuration
  const config = {
    api: {
      baseUrl: '/api',
      timeout: 10000
    },
    ui: {
      toastDuration: 5000,
      animationDuration: 300,
      maxPostLength: 500
    },
    chat: {
      maxMessageLength: 500,
      typingDelay: 1000
    }
  };

  /**
   * Initialize the dashboard application
   */
  function init() {
    cacheElements();
    initTheme();
    setupEventListeners();
    loadInitialData();
    initializeNotifications();
    setupIntersectionObserver();
    showWelcomeMessage();
  }

  /**
   * Cache DOM elements for better performance
   */
  function cacheElements() {
    elements.themeToggle = document.getElementById('themeToggle');
    elements.searchInput = document.getElementById('searchInput');
    elements.notificationBadge = document.getElementById('notificationBadge');
    elements.notificationList = document.getElementById('notificationList');
    elements.postContent = document.getElementById('postContent');
    elements.feedContainer = document.getElementById('feedContainer');
    elements.chatToggle = document.getElementById('chatToggle');
    elements.chatContainer = document.getElementById('chatContainer');
    elements.chatClose = document.getElementById('chatClose');
    elements.chatMessages = document.getElementById('chatMessages');
    elements.chatInput = document.getElementById('chatInput');
    elements.toastContainer = document.getElementById('toastContainer');
  }

  /**
   * Initialize theme system
   */
  function initTheme() {
    applyTheme(state.theme);
    
    if (elements.themeToggle) {
      elements.themeToggle.addEventListener('click', toggleTheme);
      updateThemeToggleIcon();
    }
  }

  /**
   * Apply theme to document
   */
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    state.theme = theme;
    localStorage.setItem('dashboard-theme', theme);
    updateThemeToggleIcon();
  }

  /**
   * Toggle between light and dark themes
   */
  function toggleTheme() {
    const newTheme = state.theme === 'light' ? 'dark' : 'light';
    applyTheme(newTheme);
    showToast(`Tema alterado para ${newTheme === 'dark' ? 'escuro' : 'claro'}`, 'info');
    trackEvent('theme_changed', { theme: newTheme });
  }

  /**
   * Update theme toggle button icon
   */
  function updateThemeToggleIcon() {
    if (!elements.themeToggle) return;
    
    const icon = elements.themeToggle.querySelector('.material-icons');
    if (icon) {
      icon.textContent = state.theme === 'dark' ? 'light_mode' : 'dark_mode';
    }
  }

  /**
   * Setup all event listeners
   */
  function setupEventListeners() {
    // Search functionality
    if (elements.searchInput) {
      elements.searchInput.addEventListener('input', debounce(handleSearchInput, 300));
    }

    // Post creation
    if (elements.postContent) {
      elements.postContent.addEventListener('input', handlePostInput);
      elements.postContent.addEventListener('keydown', handlePostKeydown);
    }

    // Chat functionality
    if (elements.chatToggle) {
      elements.chatToggle.addEventListener('click', toggleChat);
    }
    if (elements.chatClose) {
      elements.chatClose.addEventListener('click', closeChat);
    }
    if (elements.chatInput) {
      elements.chatInput.addEventListener('keydown', handleChatKeydown);
    }

    // Window events
    window.addEventListener('resize', debounce(handleResize, 250));
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Keyboard shortcuts
    document.addEventListener('keydown', handleKeyboardShortcuts);

    // Dropdown auto-close
    document.addEventListener('click', handleDocumentClick);
  }

  /**
   * Load initial data
   */
  function loadInitialData() {
    loadNotifications();
    loadRecentPosts();
    updateUserStats();
  }

  /**
   * Handle search input
   */
  function handleSearch(event) {
    event.preventDefault();
    const query = elements.searchInput.value.trim();
    
    if (!query) {
      elements.searchInput.focus();
      return;
    }

    performSearch(query);
  }

  /**
   * Handle search input changes
   */
  function handleSearchInput(event) {
    const query = event.target.value.trim();
    if (query.length >= 2) {
      showSearchSuggestions(query);
    } else {
      hideSearchSuggestions();
    }
  }

  /**
   * Perform search
   */
  function performSearch(query) {
    showToast(`Pesquisando por "${query}"...`, 'info');
    
    // Simulate API call
    setTimeout(() => {
      const results = searchContent(query);
      displaySearchResults(results, query);
    }, 800);
    
    trackEvent('search', { query: query });
  }