// Mock data
const users = [
  { id: 1, name: "Ana Silva", avatar: "https://placehold.co/60x60/4CAF50/fff?text=A", type: "students", course: "informatica", institution: "uan", level: "avancado", points: 9850, contributions: 124, activity: "2h", achievements: 8, bio: "Estudante de Eng. Informática apaixonada por IA e desenvolvimento web." },
  { id: 2, name: "Carlos Mendes", avatar: "https://placehold.co/60x60/2196F3/fff?text=C", type: "teachers", course: "gestao", institution: "ucan", level: "avancado", points: 8720, contributions: 98, activity: "5h", achievements: 6, bio: "Professor de Gestão com 15 anos de experiência. Mentor de startups." },
  { id: 3, name: "Marta Costa", avatar: "https://placehold.co/60x60/F44336/fff?text=M", type: "mentors", course: "direito", institution: "uan", level: "avancado", points: 9200, contributions: 156, activity: "1h", achievements: 10, bio: "Mentora sênior em direito corporativo. Ajuda jovens a ingressar no mercado." },
  { id: 4, name: "João Pereira", avatar: "https://placehold.co/60x60/FF9800/fff?text=J", type: "students", course: "economia", institution: "isc", level: "intermediario", points: 7340, contributions: 67, activity: "8h", achievements: 5, bio: "Estudante de Economia com foco em finanças comportamentais." },
  { id: 5, name: "Lucia Fernandes", avatar: "https://placehold.co/60x60/9C27B0/fff?text=L", type: "teachers", course: "medicina", institution: "uan", level: "avancado", points: 8100, contributions: 112, activity: "3h", achievements: 7, bio: "Professora de Anatomia. Criadora de conteúdos interativos." },
  { id: 6, name: "Rui Almeida", avatar: "https://placehold.co/60x60/3F51B5/fff?text=R", type: "mentors", course: "informatica", institution: "ucan", level: "avancado", points: 8800, contributions: 134, activity: "4h", achievements: 9, bio: "Engenheiro de software sênior. Mentor de carreira tech." },
];

const achievementsList = [
  { name: "Primeira Contribuição", icon: "fas fa-lightbulb", color: "bg-warning", desc: "Postou pela primeira vez" },
  { name: "Top 10 Semanal", icon: "fas fa-medal", color: "bg-info", desc: "Entre os 10 mais ativos da semana" },
  { name: "Mentor Oficial", icon: "fas fa-user-tie", color: "bg-success", desc: "Tornou-se mentor certificado" },
  { name: "Especialista", icon: "fas fa-certificate", color: "bg-orange", desc: "Completou 50 contribuições" },
];

let currentType = 'students';
let currentPage = 1;
const usersPerPage = 10;

// Dark Mode
document.getElementById('themeToggle').addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
  const icon = document.querySelector('#themeToggle i');
  if (document.body.classList.contains('dark-mode')) {
    icon.classList.replace('fa-moon', 'fa-sun');
    localStorage.setItem('theme', 'dark');
  } else {
    icon.classList.replace('fa-sun', 'fa-moon');
    localStorage.setItem('theme', 'light');
  }
});

// Apply saved theme
if (localStorage.getItem('theme') === 'dark') {
  document.body.classList.add('dark-mode');
  document.querySelector('#themeToggle i').classList.replace('fa-moon', 'fa-sun');
}

// Show best user modal
function showBestUser(type) {
  const user = users.find(u => u.type === type);
  if (!user) return;
  
  document.getElementById('bestUserModalTitle').innerHTML = `<i class="fas fa-crown me-2 text-warning"></i>Melhor ${type === 'students' ? 'Estudante' : type === 'teachers' ? 'Professor' : 'Mentor'}`;
  document.getElementById('bestUserModalBody').innerHTML = `
    <div class="text-center">
      <img src="${user.avatar}" alt="${user.name}" class="rounded-circle mb-3" style="width: 100px; height: 100px;">
      <h4>${user.name}</h4>
      <p class="text-muted">${user.course} • ${user.institution}</p>
      <div class="row mt-4">
        <div class="col-4">
          <strong>${user.points}</strong>
          <small>Pontos</small>
        </div>
        <div class="col-4">
          <strong>${user.contributions}</strong>
          <small>Contribuições</small>
        </div>
        <div class="col-4">
          <strong>${user.achievements}</strong>
          <small>Conquistas</small>
        </div>
      </div>
      <p class="mt-3">${user.bio}</p>
    </div>
  `;
  const modal = new bootstrap.Modal(document.getElementById('bestUserModal'));
  modal.show();
}

// Populate podium
function updatePodium() {
  const top3 = users.slice(0, 3);
  const podium = document.getElementById('podium');
  podium.innerHTML = `
    <div class="podium-item second">
      <div class="podium-rank">2º</div>
      <img src="${top3[1].avatar}" alt="${top3[1].name}" class="podium-avatar">
      <div class="podium-name">${top3[1].name}</div>
      <div class="podium-points">${top3[1].points} pts</div>
    </div>
    <div class="podium-item first">
      <div class="podium-rank">1º</div>
      <img src="${top3[0].avatar}" alt="${top3[0].name}" class="podium-avatar">
      <div class="podium-name">${top3[0].name}</div>
      <div class="podium-points">${top3[0].points} pts</div>
    </div>
    <div class="podium-item third">
      <div class="podium-rank">3º</div>
      <img src="${top3[2].avatar}" alt="${top3[2].name}" class="podium-avatar">
      <div class="podium-name">${top3[2].name}</div>
      <div class="podium-points">${top3[2].points} pts</div>
    </div>
  `;
}

// Populate ranking table
function updateRanking() {
  const filtered = users.filter(user => {
    const course = document.getElementById('courseFilter').value;
    const institution = document.getElementById('institutionFilter').value;
    const level = document.getElementById('levelFilter').value;
    const sortBy = document.getElementById('sortBy').value;
    
    if (course && user.course !== course) return false;
    if (institution && user.institution !== institution) return false;
    if (level && user.level !== level) return false;
    return true;
  }).sort((a, b) => b.points - a.points);

  const start = (currentPage - 1) * usersPerPage;
  const paginated = filtered.slice(start, start + usersPerPage);

  const tbody = document.getElementById('rankingTableBody');
  tbody.innerHTML = paginated.map((user, index) => `
    <tr>
      <td><strong>${start + index + 1}º</strong></td>
      <td>
        <div class="d-flex align-items-center">
          <img src="${user.avatar}" alt="${user.name}" class="rounded-circle me-3" style="width: 40px; height: 40px;">
          <div>
            <strong>${user.name}</strong>
            <div class="text-muted small">${user.course}</div>
          </div>
        </div>
      </td>
      <td><span class="badge bg-primary">${user.level === 'iniciante' ? '1-3' : user.level === 'intermediario' ? '4-6' : '7-10'}</span></td>
      <td><strong>${user.points}</strong></td>
      <td>
        <div class="achievements">
          ${[...Array(user.achievements)].map(() => '<i class="fas fa-star text-warning"></i>').join('')}
          <button class="btn btn-sm btn-outline-info ms-2" onclick="showAchievements(${user.id})">Ver</button>
        </div>
      </td>
      <td><span class="badge bg-success">${user.activity} ativo</span></td>
      <td>
        <button class="btn btn-sm btn-outline-orange" onclick="showUserProfile(${user.id})">
          <i class="fas fa-eye"></i>
        </button>
      </td>
    </tr>
  `).join('');

  document.getElementById('tableInfo').textContent = `Mostrando ${start + 1}-${start + paginated.length} de ${filtered.length} usuários`;
  document.getElementById('totalPages').textContent = Math.ceil(filtered.length / usersPerPage);
  document.getElementById('currentPage').textContent = currentPage;
  document.getElementById('prevPage').disabled = currentPage === 1;
  document.getElementById('nextPage').disabled = currentPage === Math.ceil(filtered.length / usersPerPage);
}

function showAchievements(userId) {
  const user = users.find(u => u.id === userId);
  const modalBody = document.getElementById('achievementModalBody');
  modalBody.innerHTML = `
    <p><strong>${user.name}</strong> conquistou:</p>
    <div class="row">
      ${achievementsList.slice(0, user.achievements).map(ach => `
        <div class="col-6 mb-3">
          <div class="achievement-item p-3 rounded ${ach.color} text-white">
            <i class="${ach.icon} me-2"></i>
            <strong>${ach.name}</strong>
            <div class="small mt-1">${ach.desc}</div>
          </div>
        </div>
      `).join('')}
    </div>
  `;
  const modal = new bootstrap.Modal(document.getElementById('achievementModal'));
  modal.show();
}

function showUserProfile(userId) {
  const user = users.find(u => u.id === userId);
  document.getElementById('userModalTitle').textContent = `Perfil: ${user.name}`;
  document.getElementById('userModalBody').innerHTML = `
    <div class="text-center mb-4">
      <img src="${user.avatar}" alt="${user.name}" class="rounded-circle mb-3" style="width: 120px; height: 120px;">
      <h4>${user.name}</h4>
      <p class="text-muted">${user.course} • ${user.institution}</p>
      <div class="badge bg-primary mb-3">${user.level === 'iniciante' ? 'Nível 1-3' : user.level === 'intermediario' ? 'Nível 4-6' : 'Nível 7-10'}</div>
    </div>
    <div class="row">
      <div class="col-4 text-center">
        <strong class="d-block">${user.points}</strong>
        <small>Pontos</small>
      </div>
      <div class="col-4 text-center">
        <strong class="d-block">${user.contributions}</strong>
        <small>Contribuições</small>
      </div>
      <div class="col-4 text-center">
        <strong class="d-block">${user.achievements}</strong>
        <small>Conquistas</small>
      </div>
    </div>
    <p class="mt-4">${user.bio}</p>
  `;
  const modal = new bootstrap.Modal(document.getElementById('userModal'));
  modal.show();
}

// Pagination
document.getElementById('prevPage').addEventListener('click', () => {
  if (currentPage > 1) {
    currentPage--;
    updateRanking();
  }
});

document.getElementById('nextPage').addEventListener('click', () => {
  currentPage++;
  updateRanking();
});

// Filters
document.querySelectorAll('#courseFilter, #institutionFilter, #levelFilter, #sortBy').forEach(el => {
  el.addEventListener('change', () => {
    currentPage = 1;
    updateRanking();
  });
});

// Refresh
document.getElementById('refreshRankingBtn').addEventListener('click', () => {
  updateRanking();
  const alert = document.createElement('div');
  alert.className = 'alert alert-success alert-dismissible fade show position-fixed top-0 end-0 m-3';
  alert.style.zIndex = '1000';
  alert.innerHTML = '<i class="fas fa-sync-alt me-2"></i>Ranking atualizado!';
  alert.innerHTML += '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
  document.body.appendChild(alert);
  setTimeout(() => alert.remove(), 3000);
});

// Export
document.getElementById('exportRankingBtn').addEventListener('click', () => {
  alert('Exportando ranking para CSV...');
  // Implementar exportação real com biblioteca como Papaparse ou Blob
});

// Initial load
document.addEventListener('DOMContentLoaded', () => {
  updatePodium();
  updateRanking();
  document.getElementById('loadingOverlay').style.display = 'none';
});