/**
 * Repository Application - Academic Document Management System
 * @author Academicoapp Team
 * @version 1.0.0
 */

// Main Application Module
const RepositoryApp = (function() {
  'use strict';

  // Application State
  const state = {
    favorites: JSON.parse(localStorage.getItem('resourceFavorites')) || [],
    currentFilters: {
      types: [],
      level: '',
      area: ''
    },
    currentSort: 'relevance',
    searchQuery: '',
    isLoading: false
  };

  // DOM Elements Cache
  const elements = {};

  // Configuration
  const config = {
    storageKeys: {
      favorites: 'resourceFavorites',
      preferences: 'userPreferences'
    },
    animations: {
      duration: 300,
      easing: 'ease-out'
    },
    debounceDelay: 300
  };

  /**
   * Initialize the application
   */
  function init() {
    cacheElements();
    setupEventListeners();
    loadFavorites();
    updateResultCount();
    showWelcomeMessage();
  }

  /**
   * Cache DOM elements for better performance
   */
  function cacheElements() {
    elements.searchForm = document.getElementById('searchForm');
    elements.searchInput = document.getElementById('searchInput');
    elements.searchBtn = elements.searchForm?.querySelector('.search-btn');
    elements.documentsGrid = document.getElementById('documentsGrid');
    elements.resultCount = document.getElementById('resultCount');
    elements.sortSelect = document.getElementById('sortSelect');
    elements.levelSelect = document.getElementById('levelSelect');
    elements.areaSelect = document.getElementById('areaSelect');
    elements.loadMoreBtn = document.getElementById('loadMoreBtn');
    elements.toastContainer = document.getElementById('toastContainer');
    elements.filterCheckboxes = document.querySelectorAll('[data-filter]');
  }

  /**
   * Setup all event listeners
   */
  function setupEventListeners() {
    // Search functionality
    if (elements.searchForm) {
      elements.searchForm.addEventListener('submit', handleSearch);
    }

    // Filter checkboxes
    elements.filterCheckboxes.forEach(checkbox => {
      checkbox.addEventListener('change', debounce(handleFilterChange, config.debounceDelay));
    });

    // Select filters
    if (elements.levelSelect) {
      elements.levelSelect.addEventListener('change', handleFilterChange);
    }
    if (elements.areaSelect) {
      elements.areaSelect.addEventListener('change', handleFilterChange);
    }
    if (elements.sortSelect) {
      elements.sortSelect.addEventListener('change', handleSortChange);
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', handleKeyboardShortcuts);

    // Load more button
    if (elements.loadMoreBtn) {
      elements.loadMoreBtn.addEventListener('click', loadMore);
    }

    // Window resize handler for responsive behavior
    window.addEventListener('resize', debounce(handleResize, 250));
  }

  /**
   * Handle search form submission
   */
  function handleSearch(event) {
    event.preventDefault();
    
    const query = elements.searchInput.value.trim();
    
    if (!query) {
      showNotification('Por favor, digite um termo para pesquisar', 'warning');
      elements.searchInput.focus();
      return;
    }

    state.searchQuery = query.toLowerCase();
    showSearchLoading(true);

    // Simulate search delay
    setTimeout(() => {
      filterDocuments();
      showSearchLoading(false);
      showNotification(`Encontrados resultados para "${query}"`, 'success');
      
      // Analytics tracking (if implemented)
      trackEvent('search', { query: query });
    }, 800);
  }

  /**
   * Show/hide search loading state
   */
  function showSearchLoading(isLoading) {
    if (!elements.searchBtn) return;

    if (isLoading) {
      elements.searchBtn.innerHTML = '<div class="loading"></div>';
      elements.searchBtn.disabled = true;
    } else {
      elements.searchBtn.innerHTML = '<span class="material-icons">search</span>';
      elements.searchBtn.disabled = false;
    }
  }

  /**
   * Handle filter changes
   */
  function handleFilterChange() {
    // Collect active type filters
    state.currentFilters.types = Array.from(elements.filterCheckboxes)
      .filter(cb => cb.checked)
      .map(cb => cb.dataset.filter);
    
    // Collect select filters
    state.currentFilters.level = elements.levelSelect?.value || '';
    state.currentFilters.area = elements.areaSelect?.value || '';

    filterDocuments();
    updateResultCount();
    
    // Show filter feedback
    const activeFiltersCount = state.currentFilters.types.length + 
      (state.currentFilters.level ? 1 : 0) + 
      (state.currentFilters.area ? 1 : 0);
    
    if (activeFiltersCount > 0) {
      showNotification(`${activeFiltersCount} filtro${activeFiltersCount > 1 ? 's' : ''} aplicado${activeFiltersCount > 1 ? 's' : ''}`, 'info');
    }
  }

  /**
   * Handle sort changes
   */
  function handleSortChange(event) {
    state.currentSort = event.target.value;
    sortDocuments();
    showNotification(`Documentos ordenados por ${getSortLabel(state.currentSort)}`, 'info');
    
    trackEvent('sort', { sortBy: state.currentSort });
  }

  /**
   * Filter documents based on current state
   */
  function filterDocuments() {
    const documents = elements.documentsGrid?.querySelectorAll(':scope > div') || [];
    let visibleCount = 0;

    documents.forEach(doc => {
      let isVisible = true;

      // Search query filter
      if (state.searchQuery) {
        const title = doc.querySelector('.doc-title')?.textContent.toLowerCase() || '';
        const meta = doc.querySelector('.doc-meta')?.textContent.toLowerCase() || '';
        isVisible = title.includes(state.searchQuery) || meta.includes(state.searchQuery);
      }

      // Type filter
      if (state.currentFilters.types.length > 0 && isVisible) {
        const docType = doc.dataset.type;
        isVisible = state.currentFilters.types.includes(docType);
      }

      // Level filter
      if (state.currentFilters.level && isVisible) {
        const docLevel = doc.dataset.level;
        isVisible = docLevel === state.currentFilters.level;
      }

      // Area filter
      if (state.currentFilters.area && isVisible) {
        const docArea = doc.dataset.area;
        isVisible = docArea === state.currentFilters.area;
      }

      // Apply visibility with animation
      if (isVisible) {
        doc.style.display = 'block';
        doc.style.opacity = '0';
        requestAnimationFrame(() => {
          doc.style.transition = 'opacity 0.3s ease';
          doc.style.opacity = '1';
        });
        visibleCount++;
      } else {
        doc.style.transition = 'opacity 0.2s ease';
        doc.style.opacity = '0';
        setTimeout(() => {
          doc.style.display = 'none';
        }, 200);
      }
    });

    // Update result count
    if (elements.resultCount) {
      elements.resultCount.textContent = visibleCount;
    }

    // Show "no results" message if needed
    if (visibleCount === 0) {
      showNoResultsMessage();
    } else {
      hideNoResultsMessage();
    }
  }

  /**
   * Sort documents based on current sort criteria
   */
  function sortDocuments() {
    if (!elements.documentsGrid) return;

    const documents = Array.from(elements.documentsGrid.children);

    documents.sort((a, b) => {
      switch (state.currentSort) {
        case 'date':
          return sortByDate(a, b);
        case 'popularity':
        case 'rating':
          return sortByRating(a, b);
        case 'title':
          return sortByTitle(a, b);
        default: // relevance
          return 0; // Keep original order
      }
    });

    // Re-append sorted documents with animation
    documents.forEach((doc, index) => {
      setTimeout(() => {
        elements.documentsGrid.appendChild(doc);
      }, index * 50);
    });
  }

  /**
   * Sort comparison functions
   */
  function sortByDate(a, b) {
    const yearA = parseInt(a.querySelector('.doc-meta')?.textContent.match(/\d{4}/)?.[0] || 0);
    const yearB = parseInt(b.querySelector('.doc-meta')?.textContent.match(/\d{4}/)?.[0] || 0);
    return yearB - yearA;
  }

  function sortByRating(a, b) {
    const ratingA = parseFloat(a.querySelector('.rating-text')?.textContent || 0);
    const ratingB = parseFloat(b.querySelector('.rating-text')?.textContent || 0);
    return ratingB - ratingA;
  }

  function sortByTitle(a, b) {
    const titleA = a.querySelector('.doc-title')?.textContent.toLowerCase() || '';
    const titleB = b.querySelector('.doc-title')?.textContent.toLowerCase() || '';
    return titleA.localeCompare(titleB);
  }

  /**
   * Load and apply saved favorites
   */
  function loadFavorites() {
    state.favorites.forEach(id => {
      const favoriteBtn = document.querySelector(`[data-id="${id}"] .favorite-btn`);
      if (favoriteBtn) {
        setFavoriteState(favoriteBtn, true);
      }
    });
  }

  /**
   * Toggle favorite status
   */
  function toggleFavorite(button) {
    const card = button.closest('.doc-card');
    const cardId = card?.dataset.id;
    
    if (!cardId) {
      console.error('Card ID not found');
      return;
    }

    const isCurrentlyFavorite = button.classList.contains('active');
    
    if (isCurrentlyFavorite) {
      removeFavorite(cardId, button);
    } else {
      addFavorite(cardId, button);
    }

    saveFavorites();
  }

  /**
   * Add document to favorites
   */
  function addFavorite(cardId, button) {
    state.favorites.push(cardId);
    setFavoriteState(button, true);
    showNotification('Adicionado aos favoritos!', 'success');
    trackEvent('favorite_add', { documentId: cardId });
  }

  /**
   * Remove document from favorites
   */
  function removeFavorite(cardId, button) {
    state.favorites = state.favorites.filter(id => id !== cardId);
    setFavoriteState(button, false);
    showNotification('Removido dos favoritos', 'info');
    trackEvent('favorite_remove', { documentId: cardId });
  }

  /**
   * Set favorite button visual state
   */
  function setFavoriteState(button, isFavorite) {
    const icon = button.querySelector('.material-icons');
    
    if (isFavorite) {
      button.classList.add('active');
      icon.textContent = 'favorite';
    } else {
      button.classList.remove('active');
      icon.textContent = 'favorite_border';
    }
  }

  /**
   * Save favorites to localStorage
   */
  function saveFavorites() {
    try {
      localStorage.setItem(config.storageKeys.favorites, JSON.stringify(state.favorites));
    } catch (error) {
      console.error('Failed to save favorites:', error);
      showNotification('Erro ao salvar favoritos', 'error');
    }
  }

  /**
   * Document actions
   */
  function readDocument(filename) {
    showNotification(`Abrindo ${filename} para leitura...`, 'info');
    trackEvent('document_read', { filename });
    
    // Simulate opening document
    setTimeout(() => {
      showNotification('Documento aberto com sucesso!', 'success');
    }, 1000);
  }

  function downloadResource(filename) {
    const button = event?.target?.closest('.action-btn');
    if (!button) return;

    const originalContent = button.innerHTML;
    
    // Show loading state
    button.innerHTML = '<div class="loading me-2"></div>Baixando...';
    button.disabled = true;

    // Simulate download
    setTimeout(() => {
      button.innerHTML = originalContent;
      button.disabled = false;
      showNotification(`${filename} baixado com sucesso!`, 'success');
      trackEvent('document_download', { filename });
    }, 2000);
  }

  function playVideo(videoId) {
    showNotification(`Reproduzindo vídeo: ${videoId}`, 'info');
    trackEvent('video_play', { videoId });
    // In production: open video player modal or redirect
  }

  /**
   * Load more documents
   */
  function loadMore() {
    if (state.isLoading) return;

    state.isLoading = true;
    const button = elements.loadMoreBtn;
    const textSpan = button?.querySelector('.text');
    const loader = button?.querySelector('.loading');
    
    // Show loading state
    if (textSpan) textSpan.textContent = 'Carregando...';
    if (loader) loader.classList.remove('d-none');
    if (button) button.disabled = true;

    // Simulate loading more documents
    setTimeout(() => {
      addMoreDocuments();
      
      // Reset button state
      if (textSpan) textSpan.textContent = 'Carregar mais documentos';
      if (loader) loader.classList.add('d-none');
      if (button) button.disabled = false;
      
      state.isLoading = false;
      showNotification('Novos documentos carregados!', 'success');
      trackEvent('load_more');
    }, 1500);
  }

  /**
   * Add new documents to the grid
   */
  function addMoreDocuments() {
    const grid = elements.documentsGrid;
    if (!grid) return;

    const newDocuments = [
      {
        id: `doc-${Date.now()}-1`,
        type: 'apostila',
        level: 'superior',
        area: 'biologicas',
        title: 'Apostila: Biologia Celular',
        meta: 'IMEP • 2023 • 45 páginas',
        rating: 3.8,
        badge: 'Apostila',
        badgeClass: 'bg-info',
        icon: 'description',
        iconColor: 'text-success',
        coverClass: 'doc-cover--green'
      },
      {
        id: `doc-${Date.now()}-2`,
        type: 'tese',
        level: 'pos',
        area: 'humanas',
        title: 'TCC: Sustentabilidade nas Escolas',
        meta: 'U. Soyo • 2023 • 68 páginas',
        rating: 5.0,
        badge: 'TCC',
        badgeClass: 'bg-secondary',
        icon: 'school',
        iconColor: 'text-danger',
        coverClass: 'doc-cover--purple'
      },
      {
        id: `doc-${Date.now()}-3`,
        type: 'ebook',
        level: 'superior',
        area: 'humanas',
        title: 'Economia e Desenvolvimento',
        meta: 'Dr. Mendes • 2022 • 210 páginas',
        rating: 3.0,
        badge: 'E-book',
        badgeClass: 'bg-primary',
        icon: 'book',
        iconColor: 'text-primary',
        coverClass: 'doc-cover'
      }
    ];

    newDocuments.forEach((doc, index) => {
      setTimeout(() => {
        const docElement = createDocumentElement(doc);
        grid.appendChild(docElement);
        
        // Animate in
        requestAnimationFrame(() => {
          docElement.style.opacity = '0';
          docElement.style.transform = 'translateY(20px)';
          docElement.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
          
          requestAnimationFrame(() => {
            docElement.style.opacity = '1';
            docElement.style.transform = 'translateY(0)';
          });
        });
      }, index * 200);
    });

    updateResultCount();
  }

  /**
   * Create a document element from data
   */
  function createDocumentElement(doc) {
    const col = document.createElement('div');
    col.className = 'col-md-6 col-xl-4';
    col.setAttribute('data-type', doc.type);
    col.setAttribute('data-level', doc.level);
    col.setAttribute('data-area', doc.area);
    col.setAttribute('data-id', doc.id);

    col.innerHTML = `
      <article class="doc-card">
        <div class="doc-cover ${doc.coverClass || ''}">
          <div class="text-center">
            <span class="material-icons doc-icon ${doc.iconColor}">${doc.icon}</span>
            <div class="doc-cover-text">${doc.title.split(':')[1] || doc.title}</div>
          </div>
        </div>
        <div class="doc-content">
          <div class="doc-header">
            <span class="badge ${doc.badgeClass} doc-badge">${doc.badge}</span>
            <button class="favorite-btn" onclick="RepositoryApp.toggleFavorite(this)" aria-label="Favoritar">
              <span class="material-icons">favorite_border</span>
            </button>
          </div>
          <h3 class="doc-title">${doc.title}</h3>
          <p class="doc-meta">${doc.meta}</p>
          <div class="rating">
            ${generateStars(doc.rating)}
            <span class="rating-text">${doc.rating}</span>
          </div>
          <div class="doc-actions">
            <button class="btn btn-outline-primary action-btn" onclick="RepositoryApp.readDocument('${generateFilename(doc.title)}')">
              <span class="material-icons">visibility</span>Ler
            </button>
            <button class="btn btn-primary action-btn" onclick="RepositoryApp.downloadResource('${generateFilename(doc.title)}')">
              <span class="material-icons">download</span>Baixar
            </button>
          </div>
        </div>
      </article>
    `;

    return col;
  }

  /**
   * Generate star rating HTML
   */
  function generateStars(rating) {
    let starsHtml = '';
    for (let i = 1; i <= 5; i++) {
      if (i <= Math.floor(rating)) {
        starsHtml += '<span class="material-icons star">star</span>';
      } else if (i === Math.ceil(rating) && rating % 1 !== 0) {
        starsHtml += '<span class="material-icons star">star_half</span>';
      } else {
        starsHtml += '<span class="material-icons star empty">star_border</span>';
      }
    }
    return starsHtml;
  }

  /**
   * Generate filename from title
   */
  function generateFilename(title) {
    return title.toLowerCase()
      .replace(/[^a-z0-9\s]/g, '')
      .replace(/\s+/g, '_')
      .substring(0, 50) + '.pdf';
  }

  /**
   * Update result count display
   */
  function updateResultCount() {
    if (!elements.documentsGrid || !elements.resultCount) return;

    const visibleDocs = elements.documentsGrid.querySelectorAll(':scope > div:not([style*="none"])');
    elements.resultCount.textContent = visibleDocs.length;
  }

  /**
   * Show/hide no results message
   */
  function showNoResultsMessage() {
    let noResults = document.getElementById('noResultsMessage');
    if (!noResults) {
      noResults = document.createElement('div');
      noResults.id = 'noResultsMessage';
      noResults.className = 'text-center py-5';
      noResults.innerHTML = `
        <div class="text-muted">
          <span class="material-icons" style="font-size: 4rem; opacity: 0.5;">search_off</span>
          <h3>Nenhum documento encontrado</h3>
          <p>Tente ajustar os filtros ou usar termos diferentes na busca.</p>
          <button class="btn btn-primary" onclick="RepositoryApp.clearFilters()">Limpar filtros</button>
        </div>
      `;
      elements.documentsGrid?.parentNode.appendChild(noResults);
    }
    noResults.style.display = 'block';
  }

  function hideNoResultsMessage() {
    const noResults = document.getElementById('noResultsMessage');
    if (noResults) {
      noResults.style.display = 'none';
    }
  }

  /**
   * Clear all filters and search
   */
  function clearFilters() {
    // Reset filter state
    state.currentFilters = { types: [], level: '', area: '' };
    state.searchQuery = '';

    // Reset UI
    elements.filterCheckboxes.forEach(cb => cb.checked = false);
    if (elements.levelSelect) elements.levelSelect.value = '';
    if (elements.areaSelect) elements.areaSelect.value = '';
    if (elements.searchInput) elements.searchInput.value = '';

    // Apply changes
    filterDocuments();
    updateResultCount();
    hideNoResultsMessage();
    
    showNotification('Filtros removidos', 'info');
  }

  /**
   * Handle keyboard shortcuts
   */
  function handleKeyboardShortcuts(event) {
    // Ctrl/Cmd + K to focus search
    if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
      event.preventDefault();
      elements.searchInput?.focus();
    }
    
    // Escape to clear search
    if (event.key === 'Escape' && elements.searchInput === document.activeElement) {
      if (elements.searchInput.value) {
        elements.searchInput.value = '';
        state.searchQuery = '';
        filterDocuments();
      } else {
        elements.searchInput.blur();
      }
    }
  }

  /**
   * Handle window resize
   */
  function handleResize() {
    // Responsive adjustments if needed
    updateResultCount();
  }

  /**
   * Show notification toast
   */
  function showNotification(message, type = 'info', duration = 5000) {
    if (!elements.toastContainer) return;

    const toastId = `toast-${Date.now()}`;
    const bgClass = {
      'success': 'bg-success',
      'error': 'bg-danger',
      'warning': 'bg-warning',
      'info': 'bg-primary'
    }[type] || 'bg-primary';

    const toast = document.createElement('div');
    toast.id = toastId;
    toast.className = `toast align-items-center text-white ${bgClass} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
      <div class="d-flex">
        <div class="toast-body">${message}</div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                onclick="this.closest('.toast').remove()" 
                aria-label="Fechar"></button>
      </div>
    `;
    
    elements.toastContainer.appendChild(toast);
    
    // Auto remove
    setTimeout(() => {
      if (document.getElementById(toastId)) {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
      }
    }, duration);
  }

  /**
   * Show welcome message
   */
  function showWelcomeMessage() {
    setTimeout(() => {
      showNotification('Bem-vindo ao Repositório Acadêmico!', 'success');
    }, 1000);
  }

  /**
   * Get sort label in Portuguese
   */
  function getSortLabel(sortValue) {
    const labels = {
      'relevance': 'relevância',
      'date': 'data',
      'popularity': 'popularidade',
      'rating': 'avaliação',
      'title': 'título'
    };
    return labels[sortValue] || sortValue;
  }

  /**
   * Track events (analytics placeholder)
   */
  function trackEvent(eventName, data = {}) {
    // Placeholder for analytics tracking
    console.log('Event:', eventName, data);
    
    // Example: Google Analytics 4
    // if (typeof gtag !== 'undefined') {
    //   gtag('event', eventName, data);
    // }
  }

  /**
   * Debounce function to limit function calls
   */
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func.apply(this, args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // Public API
  return {
    init,
    toggleFavorite,
    readDocument,
    downloadResource,
    playVideo,
    loadMore,
    clearFilters
  };

})();

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', RepositoryApp.init);

// Handle page visibility changes
document.addEventListener('visibilitychange', function() {
  if (document.visibilityState === 'visible') {
    // Refresh data if page becomes visible after being hidden
    console.log('Page became visible - refresh if needed');
  }
});

// Service Worker registration (for offline functionality)
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function() {
    navigator.serviceWorker.register('/sw.js')
      .then(function(registration) {
        console.log('ServiceWorker registration successful');
      })
      .catch(function(err) {
        console.log('ServiceWorker registration failed');
      });
  });
}