/**
 * Suporte Acadêmico - JavaScript
 * AcademicoApp v1.0
 */

// ==================== Configuração ====================
const CONFIG = {
  minDate: new Date().toISOString().split('T')[0],
  maxDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  emailEndpoint: 'https://api.academicapp.com/suporte/academico', // Endpoint fictício
  storageKey: 'academico_suporte_data'
};

// ==================== Inicialização ====================
document.addEventListener('DOMContentLoaded', function() {
  initializeForm();
  initializeTheme();
  setupEventListeners();
  setupDateRestrictions();
  loadSavedData();
  initializeAnimations();
});

// ==================== Formulário ====================
function initializeForm() {
  const form = document.getElementById('bookingForm');
  if (!form) return;

  // Bootstrap validation
  form.addEventListener('submit', function(event) {
    event.preventDefault();
    event.stopPropagation();

    if (form.checkValidity()) {
      handleFormSubmit();
    }

    form.classList.add('was-validated');
  }, false);
}

function handleFormSubmit() {
  const formData = collectFormData();
  
  // Simular loading
  showLoading(true);
  
  // Simular envio (em produção, fazer requisição real)
  setTimeout(() => {
    // Salvar dados localmente
    saveFormData(formData);
    
    // Mostrar sucesso
    showSuccessMessage();
    
    // Limpar formulário
    resetForm();
    
    // Esconder loading
    showLoading(false);
    
    // Log para desenvolvimento
    console.log('Dados do formulário:', formData);
    
    // Em produção, enviar para o servidor
    // sendToServer(formData);
  }, 1500);
}

function collectFormData() {
  return {
    area: document.getElementById('area').value,
    tipo: document.getElementById('tipo').value,
    data: document.getElementById('data').value,
    horario: document.getElementById('horario').value,
    descricao: document.getElementById('descricao').value,
    timestamp: new Date().toISOString(),
    page: 'academico'
  };
}

function saveFormData(data) {
  try {
    const existing = localStorage.getItem(CONFIG.storageKey);
    const allData = existing ? JSON.parse(existing) : [];
    allData.push(data);
    localStorage.setItem(CONFIG.storageKey, JSON.stringify(allData));
  } catch (e) {
    console.error('Erro ao salvar dados:', e);
  }
}

function loadSavedData() {
  try {
    const saved = localStorage.getItem(CONFIG.storageKey);
    if (saved) {
      const data = JSON.parse(saved);
      console.log(`${data.length} solicitações anteriores encontradas`);
    }
  } catch (e) {
    console.error('Erro ao carregar dados:', e);
  }
}

// ==================== UI Feedback ====================
function showSuccessMessage() {
  const successMsg = document.getElementById('successMessage');
  if (successMsg) {
    successMsg.classList.remove('d-none');
    successMsg.scrollIntoView({ behavior: 'smooth', block: 'center' });
    
    // Auto-hide após 10 segundos
    setTimeout(() => {
      successMsg.classList.add('d-none');
    }, 10000);
  }
}

function showLoading(show) {
  const btn = document.querySelector('button[type="submit"]');
  if (!btn) return;
  
  if (show) {
    btn.disabled = true;
    btn.innerHTML = '<span class="loading-spinner me-2"></span>Enviando...';
  } else {
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-paper-plane me-2"></i>Solicitar Agendamento';
  }
}

function resetForm() {
  const form = document.getElementById('bookingForm');
  if (form) {
    form.reset();
    form.classList.remove('was-validated');
  }
}

// ==================== Validações e Restrições ====================
function setupDateRestrictions() {
  const dateInput = document.getElementById('data');
  if (dateInput) {
    dateInput.min = CONFIG.minDate;
    dateInput.max = CONFIG.maxDate;
    
    // Adicionar validação customizada
    dateInput.addEventListener('change', function() {
      const selectedDate = new Date(this.value);
      const today = new Date();
      const maxDate = new Date(CONFIG.maxDate);
      
      if (selectedDate < today) {
        this.setCustomValidity('Por favor, selecione uma data futura.');
      } else if (selectedDate > maxDate) {
        this.setCustomValidity('Por favor, selecione uma data nos próximos 90 dias.');
      } else if (selectedDate.getDay() === 0) { // Domingo
        this.setCustomValidity('Não há atendimento aos domingos.');
      } else {
        this.setCustomValidity('');
      }
    });
  }
}

// ==================== Event Listeners ====================
function setupEventListeners() {
  // Tipo de suporte - atualizar descrição
  const tipoSelect = document.getElementById('tipo');
  if (tipoSelect) {
    tipoSelect.addEventListener('change', function() {
      updateSupportDescription(this.value);
    });
  }
  
  // Área de estudo - sugerir mentores
  const areaSelect = document.getElementById('area');
  if (areaSelect) {
    areaSelect.addEventListener('change', function() {
      suggestMentors(this.value);
    });
  }
  
  // Contador de caracteres para descrição
  const descricaoTextarea = document.getElementById('descricao');
  if (descricaoTextarea) {
    descricaoTextarea.addEventListener('input', function() {
      updateCharacterCount(this);
    });
  }
}

function updateSupportDescription(tipo) {
  const descriptions = {
    mentoria: 'Sessão individual de 60 minutos com mentor especializado.',
    revisao: 'Análise detalhada com feedback em até 48h.',
    exame: 'Preparação intensiva com simulados e material de estudo.',
    tcc: 'Orientação completa desde a escolha do tema até a defesa.',
    artigo: 'Revisão de estrutura, conteúdo e formatação ABNT/APA.',
    apresentacao: 'Técnicas de apresentação e design de slides profissionais.'
  };
  
  // Poderia mostrar uma tooltip ou atualizar um elemento na página
  console.log('Tipo selecionado:', descriptions[tipo] || 'Selecione um tipo de suporte');
}

function suggestMentors(area) {
  const mentors = {
    geociencias: ['Dr. João Silva - Geologia', 'Dra. Maria Santos - Geografia'],
    engenharias: ['Eng. Pedro Costa - Civil', 'Eng. Ana Ferreira - Mecânica'],
    tecnologia: ['MSc. Carlos Tech - Desenvolvimento', 'Dra. Sofia Data - IA'],
    gestao: ['MBA Roberto Business - Estratégia', 'Dra. Paula Finance - Finanças'],
    direito: ['Dr. Miguel Law - Constitucional', 'Dra. Teresa Jurídica - Penal'],
    medicina: ['Dr. António Med - Clínica', 'Dra. Isabel Saúde - Pesquisa'],
    humanas: ['Dr. Francisco História - História', 'Dra. Mariana Letras - Literatura'],
    exatas: ['Dr. Ricardo Math - Matemática', 'Dra. Juliana Physics - Física']
  };
  
  const areaMentors = mentors[area];
  if (areaMentors) {
    console.log(`Mentores disponíveis para ${area}:`, areaMentors);
    // Poderia atualizar um elemento na página com os mentores sugeridos
  }
}

function updateCharacterCount(textarea) {
  const maxLength = 500;
  const currentLength = textarea.value.length;
  const remaining = maxLength - currentLength;
  
  // Poderia mostrar contador visual
  if (remaining < 50) {
    console.log(`Caracteres restantes: ${remaining}`);
  }
}

// ==================== Tema ====================
function initializeTheme() {
  const savedTheme = localStorage.getItem('theme');
  const themeToggle = document.getElementById('themeToggle');
  
  if (savedTheme === 'dark') {
    document.body.classList.add('dark-mode');
    if (themeToggle) {
      const icon = themeToggle.querySelector('i');
      icon.className = 'fa-solid fa-sun';
    }
  }
  
  if (themeToggle) {
    themeToggle.addEventListener('click', toggleTheme);
  }
}

function toggleTheme() {
  const body = document.body;
  const themeToggle = document.getElementById('themeToggle');
  const isDark = body.classList.toggle('dark-mode');
  
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  
  if (themeToggle) {
    const icon = themeToggle.querySelector('i');
    icon.className = isDark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
  }
}

// ==================== Animações ====================
function initializeAnimations() {
  // Observador para animações ao scroll
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate__animated', 'animate__fadeInUp');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);
  
  // Observar cards de testemunhos
  document.querySelectorAll('.testimonial-card').forEach(card => {
    observer.observe(card);
  });
  
  // Animação suave para accordion
  const accordionButtons = document.querySelectorAll('.accordion-button');
  accordionButtons.forEach(button => {
    button.addEventListener('click', function() {
      // Bootstrap já lida com isso, mas podemos adicionar efeitos extras
      const icon = this.querySelector('i');
      if (icon) {
        icon.style.transform = this.classList.contains('collapsed') ? 'rotate(0deg)' : 'rotate(180deg)';
      }
    });
  });
}

// ==================== Utilidades ====================
function formatDate(dateString) {
  const options = { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric',
    weekday: 'long'
  };
  return new Date(dateString).toLocaleDateString('pt-PT', options);
}

function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// ==================== API (Simulada) ====================
async function sendToServer(data) {
  try {
    // Em produção, fazer requisição real
    const response = await fetch(CONFIG.emailEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data)
    });
    
    if (!response.ok) {
      throw new Error('Erro ao enviar dados');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Erro:', error);
    // Fallback: salvar localmente
    saveFormData(data);
  }
}

// ==================== Exportar para uso externo ====================
window.AcademicoSupport = {
  resetForm,
  collectFormData,
  formatDate,
  validateEmail
};