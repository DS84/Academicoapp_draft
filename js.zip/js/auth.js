/**
 * Authentication Application - Login & Registration System
 * @author Academicoapp Team
 * @version 2.0.0
 */

const AuthApp = (function() {
  'use strict';

  // Application State
  const state = {
    currentTab: 'login',
    theme: localStorage.getItem('auth-theme') || 'light',
    isSubmitting: false,
    passwordStrength: {
      score: 0,
      requirements: {
        length: false,
        uppercase: false,
        number: false,
        special: false
      }
    }
  };

  // DOM Elements Cache
  const elements = {};

  // Configuration
  const config = {
    api: {
      baseUrl: '/api/auth',
      timeout: 10000
    },
    validation: {
      minPasswordLength: 8,
      passwordRegex: {
        uppercase: /[A-Z]/,
        number: /[0-9]/,
        special: /[^A-Za-z0-9]/
      }
    },
    ui: {
      toastDuration: 5000,
      animationDuration: 300
    }
  };

  /**
   * Initialize the authentication application
   */
  function init() {
    cacheElements();
    initTheme();
    setupEventListeners();
    setupFormValidation();
    loadSavedData();
  }

  /**
   * Cache DOM elements for better performance
   */
  function cacheElements() {
    // Theme toggle
    elements.themeToggle = document.getElementById('themeToggle');
    
    // Tab system
    elements.authTabs = document.querySelectorAll('.auth-tab');
    elements.authPanels = document.querySelectorAll('.auth-panel');
    
    // Forms
    elements.loginForm = document.getElementById('loginForm');
    elements.registerForm = document.getElementById('registerForm');
    elements.forgotPasswordForm = document.getElementById('forgotPasswordForm');
    
    // Login fields
    elements.emailLogin = document.getElementById('emailLogin');
    elements.passwordLogin = document.getElementById('passwordLogin');
    elements.rememberMe = document.getElementById('rememberMe');
    
    // Register fields
    elements.firstName = document.getElementById('firstName');
    elements.lastName = document.getElementById('lastName');
    elements.emailRegister = document.getElementById('emailRegister');
    elements.userType = document.getElementById('userType');
    elements.passwordRegister = document.getElementById('passwordRegister');
    elements.passwordConfirm = document.getElementById('passwordConfirm');
    elements.agreeTerms = document.getElementById('agreeTerms');
    
    // Password strength
    elements.passwordStrength = document.getElementById('passwordStrength');
    
    // Modals
    elements.forgotPasswordModal = new bootstrap.Modal(document.getElementById('forgotPasswordModal'));
    elements.forgotEmail = document.getElementById('forgotEmail');
    
    // Toast container
    elements.toastContainer = document.getElementById('toastContainer');
  }

  /**
   * Initialize theme system
   */
  function initTheme() {
    applyTheme(state.theme);
    
    if (elements.themeToggle) {
      elements.themeToggle.addEventListener('click', toggleTheme);
      updateThemeToggleIcon();
    }
  }

  /**
   * Apply theme to document
   */
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    state.theme = theme;
    localStorage.setItem('auth-theme', theme);
    updateThemeToggleIcon();
  }

  /**
   * Toggle between light and dark themes
   */
  function toggleTheme() {
    const newTheme = state.theme === 'light' ? 'dark' : 'light';
    applyTheme(newTheme);
    showToast(`Tema alterado para ${newTheme === 'dark' ? 'escuro' : 'claro'}`, 'info');
  }

  /**
   * Update theme toggle button icon
   */
  function updateThemeToggleIcon() {
    if (!elements.themeToggle) return;
    
    const icon = elements.themeToggle.querySelector('i');
    if (icon) {
      icon.className = state.theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
  }

  /**
   * Setup all event listeners
   */
  function setupEventListeners() {
    // Tab switching
    elements.authTabs.forEach(tab => {
      tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });

    // Form submissions
    if (elements.loginForm) {
      elements.loginForm.addEventListener('submit', handleLogin);
    }
    if (elements.registerForm) {
      elements.registerForm.addEventListener('submit', handleRegister);
    }
    if (elements.forgotPasswordForm) {
      elements.forgotPasswordForm.addEventListener('submit', handleForgotPassword);
    }

    // Password strength checking
    if (elements.passwordRegister) {
      elements.passwordRegister.addEventListener('input', checkPasswordStrength);
    }

    // Password confirmation
    if (elements.passwordConfirm) {
      elements.passwordConfirm.addEventListener('input', validatePasswordConfirmation);
    }

    // Real-time validation
    setupRealTimeValidation();
  }

  /**
   * Switch between login and register tabs
   */
  function switchTab(tabName) {
    if (state.currentTab === tabName) return;

    // Update tab buttons
    elements.authTabs.forEach(tab => {
      tab.classList.toggle('active', tab.dataset.tab === tabName);
    });

    // Update panels
    elements.authPanels.forEach(panel => {
      const isActive = panel.id === tabName + 'Panel';
      panel.classList.toggle('active', isActive);
    });

    state.currentTab = tabName;
    
    // Clear any previous validation errors
    clearFormErrors();
    
    // Reset password strength if switching away from register
    if (tabName !== 'register' && elements.passwordStrength) {
      elements.passwordStrength.classList.remove('visible');
    }
  }

  /**
   * Setup form validation
   */
  function setupFormValidation() {
    const forms = [elements.loginForm, elements.registerForm, elements.forgotPasswordForm];
    
    forms.forEach(form => {
      if (!form) return;
      
      form.addEventListener('submit', function(e) {
        if (!form.checkValidity()) {
          e.preventDefault();
          e.stopPropagation();
        }
        form.classList.add('was-validated');
      });
    });
  }

  /**
   * Setup real-time validation
   */
  function setupRealTimeValidation() {
    const fields = [
      elements.emailLogin,
      elements.emailRegister,
      elements.firstName,
      elements.lastName,
      elements.passwordLogin,
      elements.passwordRegister,
      elements.passwordConfirm,
      elements.forgotEmail
    ];

    fields.forEach(field => {
      if (!field) return;
      
      field.addEventListener('blur', () => validateField(field));
      field.addEventListener('input', () => clearFieldError(field));
    });
  }

  /**
   * Handle login form submission
   */
  function handleLogin(event) {
    event.preventDefault();
    
    if (state.isSubmitting) return;
    
    const formData = {
      email: elements.emailLogin.value.trim(),
      password: elements.passwordLogin.value,
      remember: elements.rememberMe.checked
    };

    if (!validateLoginForm(formData)) {
      return;
    }

    performLogin(formData);
  }

  /**
   * Handle registration form submission
   */
  function handleRegister(event) {
    event.preventDefault();
    
    if (state.isSubmitting) return;
    
    const formData = {
      firstName: elements.firstName.value.trim(),
      lastName: elements.lastName.value.trim(),
      email: elements.emailRegister.value.trim(),
      userType: elements.userType.value,
      password: elements.passwordRegister.value,
      passwordConfirm: elements.passwordConfirm.value,
      agreeTerms: elements.agreeTerms.checked
    };

    if (!validateRegisterForm(formData)) {
      return;
    }

    performRegister(formData);
  }

  /**
   * Handle forgot password form submission
   */
  function handleForgotPassword(event) {
    event.preventDefault();
    
    const email = elements.forgotEmail.value.trim();
    
    if (!validateEmail(email)) {
      showFieldError(elements.forgotEmail, 'Email inválido');
      return;
    }

    performForgotPassword(email);
  }

  /**
   * Validate login form
   */
  function validateLoginForm(data) {
    let isValid = true;

    if (!validateEmail(data.email)) {
      showFieldError(elements.emailLogin, 'Email inválido');
      isValid = false;
    }

    if (!data.password || data.password.length < 6) {
      showFieldError(elements.passwordLogin, 'Senha deve ter pelo menos 6 caracteres');
      isValid = false;
    }

    return isValid;
  }

  /**
   * Validate registration form
   */
  function validateRegisterForm(data) {
    let isValid = true;

    if (!data.firstName || data.firstName.length < 2) {
      showFieldError(elements.firstName, 'Nome deve ter pelo menos 2 caracteres');
      isValid = false;
    }

    if (!data.lastName || data.lastName.length < 2) {
      showFieldError(elements.lastName, 'Apelido deve ter pelo menos 2 caracteres');
      isValid = false;
    }

    if (!validateEmail(data.email)) {
      showFieldError(elements.emailRegister, 'Email inválido');
      isValid = false;
    }

    if (!data.userType) {
      showFieldError(elements.userType, 'Selecione um tipo de perfil');
      isValid = false;
    }

    if (!validatePassword(data.password)) {
      showFieldError(elements.passwordRegister, 'Senha não atende aos requisitos mínimos');
      isValid = false;
    }

    if (data.password !== data.passwordConfirm) {
      showFieldError(elements.passwordConfirm, 'Senhas não coincidem');
      isValid = false;
    }

    if (!data.agreeTerms) {
      showFieldError(elements.agreeTerms, 'Você deve concordar com os termos');
      isValid = false;
    }

    return isValid;
  }

  /**
   * Validate email format
   */
  function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Validate password strength
   */
  function validatePassword(password) {
    return password && 
           password.length >= config.validation.minPasswordLength &&
           config.validation.passwordRegex.uppercase.test(password) &&
           config.validation.passwordRegex.number.test(password);
  }

  /**
   * Check password strength in real-time
   */
  function checkPasswordStrength() {
    const password = elements.passwordRegister.value;
    
    if (!elements.passwordStrength) return;
    
    // Show/hide strength indicator
    if (password.length > 0) {
      elements.passwordStrength.classList.add('visible');
    } else {
      elements.passwordStrength.classList.remove('visible');
      return;
    }

    // Check requirements
    const requirements = {
      length: password.length >= config.validation.minPasswordLength,
      uppercase: config.validation.passwordRegex.uppercase.test(password),
      number: config.validation.passwordRegex.number.test(password),
      special: config.validation.passwordRegex.special.test(password)
    };

    // Update requirements display
    Object.keys(requirements).forEach(req => {
      const element = elements.passwordStrength.querySelector(`[data-requirement="${req}"]`);
      if (element) {
        element.classList.toggle('met', requirements[req]);
      }
    });

    // Calculate strength score
    const score = Object.values(requirements).filter(Boolean).length;
    const strengthLevels = ['weak', 'fair', 'good', 'strong'];
    const strengthLevel = strengthLevels[Math.max(0, score - 1)] || 'weak';

    // Update progress bar
    const progressBar = elements.passwordStrength.querySelector('.strength-progress');
    if (progressBar) {
      progressBar.className = `strength-progress ${strengthLevel}`;
    }

    state.passwordStrength = { score, requirements };
  }

  /**
   * Validate password confirmation
   */
  function validatePasswordConfirmation() {
    const password = elements.passwordRegister.value;
    const confirmation = elements.passwordConfirm.value;

    if (confirmation && password !== confirmation) {
      showFieldError(elements.passwordConfirm, 'Senhas não coincidem');
    } else {
      clearFieldError(elements.passwordConfirm);
    }
  }

  /**
   * Validate individual field
   */
  function validateField(field) {
    if (!field || !field.value) return;

    const value = field.value.trim();
    
    switch (field.type) {
      case 'email':
        if (!validateEmail(value)) {
          showFieldError(field, 'Email inválido');
          return false;
        }
        break;
      case 'password':
        if (field.id === 'passwordRegister' && !validatePassword(value)) {
          showFieldError(field, 'Senha não atende aos requisitos');
          return false;
        } else if (value.length < 6) {
          showFieldError(field, 'Senha muito curta');
          return false;
        }
        break;
      default:
        if (field.required && !value) {
          showFieldError(field, 'Campo obrigatório');
          return false;
        }
    }

    clearFieldError(field);
    return true;
  }

  /**
   * Show field validation error
   */
  function showFieldError(field, message) {
    field.classList.add('is-invalid');
    field.classList.remove('is-valid');
    
    const feedback = field.parentNode.querySelector('.invalid-feedback') || 
                    field.nextElementSibling;
    if (feedback && feedback.classList.contains('invalid-feedback')) {
      feedback.textContent = message;
    }
  }

  /**
   * Clear field validation error
   */
  function clearFieldError(field) {
    field.classList.remove('is-invalid');
    if (field.value.trim()) {
      field.classList.add('is-valid');
    }
    
    const feedback = field.parentNode.querySelector('.invalid-feedback') || 
                    field.nextElementSibling;
    if (feedback && feedback.classList.contains('invalid-feedback')) {
      feedback.textContent = '';
    }
  }

  /**
   * Clear all form errors
   */
  function clearFormErrors() {
    document.querySelectorAll('.is-invalid, .is-valid').forEach(field => {
      field.classList.remove('is-invalid', 'is-valid');
    });
    
    document.querySelectorAll('.invalid-feedback').forEach(feedback => {
      feedback.textContent = '';
    });
  }

  /**
   * Perform login request
   */
  async function performLogin(data) {
    const submitBtn = elements.loginForm.querySelector('button[type="submit"]');
    setButtonLoading(submitBtn, true);
    state.isSubmitting = true;

    try {
      // Simulate API call
      await simulateApiCall();
      
      // Save remember me preference
      if (data.remember) {
        localStorage.setItem('rememberedEmail', data.email);
      }
      
      showToast('Login realizado com sucesso!', 'success');
      
      // Redirect after short delay
      setTimeout(() => {
        window.location.href = 'dashboard.html';
      }, 1500);
      
    } catch (error) {
      showToast('Email ou senha incorretos', 'error');
    } finally {
      setButtonLoading(submitBtn, false);
      state.isSubmitting = false;
    }
  }

  /**
   * Perform registration request
   */
  async function performRegister(data) {
    const submitBtn = elements.registerForm.querySelector('button[type="submit"]');
    setButtonLoading(submitBtn, true);
    state.isSubmitting = true;

    try {
      // Simulate API call
      await simulateApiCall(2000);
      
      showToast('Conta criada com sucesso!', 'success');
      
      // Switch to login tab after short delay
      setTimeout(() => {
        switchTab('login');
        elements.emailLogin.value = data.email;
      }, 1500);
      
    } catch (error) {
      showToast('Erro ao criar conta. Tente novamente.', 'error');
    } finally {
      setButtonLoading(submitBtn, false);
      state.isSubmitting = false;
    }
  }

  /**
   * Perform forgot password request
   */
  async function performForgotPassword(email) {
    const submitBtn = elements.forgotPasswordForm.querySelector('button[type="submit"]');
    setButtonLoading(submitBtn, true);

    try {
      // Simulate API call
      await simulateApiCall(1000);
      
      showToast('Link de recuperação enviado para seu email', 'success');
      elements.forgotPasswordModal.hide();
      elements.forgotPasswordForm.reset();
      
    } catch (error) {
      showToast('Erro ao enviar email de recuperação', 'error');
    } finally {
      setButtonLoading(submitBtn, false);
    }
  }

  /**
   * Handle social login
   */
  function socialLogin(provider) {
    showToast(`Redirecionando para ${provider}...`, 'info');
    
    // In production, redirect to OAuth provider
    setTimeout(() => {
      showToast('Funcionalidade em desenvolvimento', 'warning');
    }, 1500);
  }

  /**
   * Show forgot password modal
   */
  function showForgotPassword() {
    // Pre-fill email if available
    const loginEmail = elements.emailLogin.value.trim();
    if (loginEmail && validateEmail(loginEmail)) {
      elements.forgotEmail.value = loginEmail;
    }
    
    elements.forgotPasswordModal.show();
    
    // Focus email field after modal is shown
    setTimeout(() => {
      elements.forgotEmail.focus();
    }, 300);
  }

  /**
   * Toggle password visibility
   */
  function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const toggle = input.parentNode.querySelector('.password-toggle i');
    
    if (input.type === 'password') {
      input.type = 'text';
      toggle.className = 'fas fa-eye-slash';
    } else {
      input.type = 'password';
      toggle.className = 'fas fa-eye';
    }
  }

  /**
   * Set button loading state
   */
  function setButtonLoading(button, isLoading) {
    const textSpan = button.querySelector('.btn-text');
    const loadingSpan = button.querySelector('.btn-loading');
    
    if (isLoading) {
      textSpan.style.opacity = '0';
      loadingSpan.classList.remove('d-none');
      button.disabled = true;
    } else {
      textSpan.style.opacity = '1';
      loadingSpan.classList.add('d-none');
      button.disabled = false;
    }
  }

  /**
   * Load saved data (like remembered email)
   */
  function loadSavedData() {
    const rememberedEmail = localStorage.getItem('rememberedEmail');
    if (rememberedEmail && elements.emailLogin) {
      elements.emailLogin.value = rememberedEmail;
      elements.rememberMe.checked = true;
    }
  }

  /**
   * Simulate API call
   */
  function simulateApiCall(delay = 1500) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulate 90% success rate
        if (Math.random() > 0.1) {
          resolve();
        } else {
          reject(new Error('API Error'));
        }
      }, delay);
    });
  }

  /**
   * Show toast notification
   */
  function showToast(message, type = 'info', duration = config.ui.toastDuration) {
    if (!elements.toastContainer) return;

    const toastId = `toast-${Date.now()}`;
    const iconClass = {
      'success': 'fas fa-check-circle',
      'error': 'fas fa-exclamation-circle',
      'warning': 'fas fa-exclamation-triangle',
      'info': 'fas fa-info-circle'
    }[type] || 'fas fa-info-circle';

    const bgClass = {
      'success': 'bg-success',
      'error': 'bg-danger',
      'warning': 'bg-warning',
      'info': 'bg-primary'
    }[type] || 'bg-primary';

    const toast = document.createElement('div');
    toast.id = toastId;
    toast.className = `toast align-items-center text-white ${bgClass} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
      <div class="d-flex">
        <div class="toast-body d-flex align-items-center">
          <i class="${iconClass} me-2"></i>
          <span>${message}</span>
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                onclick="this.closest('.toast').remove()" 
                aria-label="Fechar"></button>
      </div>
    `;
    
    elements.toastContainer.appendChild(toast);
    
    // Animate in
    requestAnimationFrame(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.3s ease';
      
      requestAnimationFrame(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateX(0)';
      });
    });
    
    // Auto remove
    setTimeout(() => {
      if (document.getElementById(toastId)) {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
      }
    }, duration);
  }

  /**
   * Analytics tracking (placeholder)
   */
  function trackEvent(eventName, data = {}) {
    // Placeholder for analytics tracking
    console.log('Event:', eventName, data);
    
    // Example: Google Analytics 4
    // if (typeof gtag !== 'undefined') {
    //   gtag('event', eventName, data);
    // }
  }

  /**
   * Error handling
   */
  function handleError(error, context = 'Unknown') {
    console.error(`Error in ${context}:`, error);
    
    // Show user-friendly error message
    showToast('Ocorreu um erro inesperado. Tente novamente.', 'error');
    
    // Track error for monitoring
    trackEvent('error', {
      context: context,
      message: error.message,
      stack: error.stack?.substring(0, 500) // Limit stack trace length
    });
  }

  /**
   * Utility functions
   */
  const utils = {
    debounce: (func, wait) => {
      let timeout;
      return function executedFunction(...args) {
        const later = () => {
          clearTimeout(timeout);
          func.apply(this, args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
      };
    },

    throttle: (func, limit) => {
      let inThrottle;
      return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
          func.apply(context, args);
          inThrottle = true;
          setTimeout(() => inThrottle = false, limit);
        }
      };
    },

    sanitizeInput: (input) => {
      return input.trim().replace(/[<>]/g, '');
    }
  };

  // Public API
  return {
    init,
    togglePassword,
    socialLogin,
    showForgotPassword,
    switchTab
  };

})();

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', AuthApp.init);

// Handle form submissions via keyboard
document.addEventListener('keydown', function(e) {
  if (e.key === 'Enter' && e.target.matches('input')) {
    const form = e.target.closest('form');
    if (form) {
      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) {
        submitBtn.click();
      }
    }
  }
});

// Handle page visibility changes
document.addEventListener('visibilitychange', function() {
  if (document.visibilityState === 'visible') {
    // Check if user is already logged in when page becomes visible
    const token = localStorage.getItem('authToken');
    if (token) {
      // Verify token validity (in production)
      console.log('User may already be logged in');
    }
  }
});

// Handle offline/online status
window.addEventListener('offline', function() {
  AuthApp.showToast('Conexão perdida. Algumas funcionalidades podem não funcionar.', 'warning');
});

window.addEventListener('online', function() {
  AuthApp.showToast('Conexão restaurada.', 'success');
});