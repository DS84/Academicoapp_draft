// Upload de Documentos - Academicoapp
// Variável global para armazenar o arquivo selecionado
let selectedFile = null;

// Inicialização quando a página carregar
document.addEventListener('DOMContentLoaded', function() {
    initializeUpload();
});

function initializeUpload() {
    setupDragAndDrop();
    setupFileInput();
    setupFormValidation();
    setupFormSubmission();
}

// Função para voltar à página anterior
function goBack() {
    if (window.history.length > 1) {
        window.history.back();
    } else {
        window.location.href = "repositorio.html";
    }
}

// Função para abrir o seletor de arquivos
function triggerFileInput() {
    document.getElementById('docFile').click();
}

// Função para remover arquivo selecionado
function removeFile() {
    selectedFile = null;
    const fileInput = document.getElementById('docFile');
    const fileInfo = document.getElementById('fileInfo');
    const progressBar = document.getElementById('progressBar');
    const uploadArea = document.querySelector('.file-upload-area');
    
    fileInput.value = '';
    fileInfo.style.display = 'none';
    progressBar.style.display = 'none';
    uploadArea.style.display = 'block';
    
    // Remove validação
    fileInput.classList.remove('is-valid', 'is-invalid');
}

// Configurar funcionalidade de drag and drop
function setupDragAndDrop() {
    const uploadArea = document.querySelector('.file-upload-area');
    
    if (!uploadArea) return;
    
    // Prevenir comportamento padrão para todos os eventos de drag
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, preventDefaults);
        document.body.addEventListener(eventName, preventDefaults);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    // Adicionar classe visual quando arrastar sobre a área
    ['dragenter', 'dragover'].forEach(eventName => {
        uploadArea.addEventListener(eventName, () => {
            uploadArea.classList.add('dragover');
        });
    });
    
    // Remover classe visual quando sair da área
    ['dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, () => {
            uploadArea.classList.remove('dragover');
        });
    });
    
    // Processar arquivo solto
    uploadArea.addEventListener('drop', (e) => {
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFile(files[0]);
        }
    });
}

// Configurar input de arquivo
function setupFileInput() {
    const fileInput = document.getElementById('docFile');
    
    if (!fileInput) return;
    
    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFile(e.target.files[0]);
        }
    });
}

// Processar arquivo selecionado
function handleFile(file) {
    // Validar tipo de arquivo
    const validTypes = ['pdf', 'doc', 'docx', 'ppt', 'pptx'];
    const fileExtension = file.name.split('.').pop().toLowerCase();
    
    if (!validTypes.includes(fileExtension)) {
        showAlert('Tipo de arquivo não suportado. Use: PDF, DOC, DOCX, PPT, PPTX', 'error');
        return;
    }
    
    // Validar tamanho do arquivo (10MB limite)
    const maxSize = 10 * 1024 * 1024; // 10MB em bytes
    if (file.size > maxSize) {
        showAlert('Arquivo muito grande. Limite máximo: 10MB', 'error');
        return;
    }
    
    // Arquivo válido - armazenar e mostrar informações
    selectedFile = file;
    displayFileInfo(file);
    simulateUploadProgress();
}

// Mostrar informações do arquivo
function displayFileInfo(file) {
    const fileName = document.getElementById('fileName');
    const fileInfo = document.getElementById('fileInfo');
    const uploadArea = document.querySelector('.file-upload-area');
    const fileInput = document.getElementById('docFile');
    
    if (fileName && fileInfo && uploadArea) {
        fileName.textContent = file.name;
        fileInfo.style.display = 'flex';
        uploadArea.style.display = 'none';
        
        // Adicionar classe de validação
        fileInput.classList.remove('is-invalid');
        fileInput.classList.add('is-valid');
    }
}

// Simular progresso de upload
function simulateUploadProgress() {
    const progressBar = document.getElementById('progressBar');
    const progressFill = document.getElementById('progressFill');
    
    if (!progressBar || !progressFill) return;
    
    progressBar.style.display = 'block';
    progressFill.style.width = '0%';
    
    let progress = 0;
    const interval = setInterval(() => {
        // Incremento aleatório para simular upload real
        progress += Math.random() * 10 + 5;
        
        if (progress >= 100) {
            progress = 100;
            clearInterval(interval);
            
            // Esconder barra após completar
            setTimeout(() => {
                progressBar.style.display = 'none';
            }, 1500);
        }
        
        progressFill.style.width = progress + '%';
    }, 150);
}

// Configurar validação do formulário
function setupFormValidation() {
    const formElements = document.querySelectorAll('input[required], select[required], textarea[required]');
    
    formElements.forEach(element => {
        // Validação em tempo real
        element.addEventListener('blur', function() {
            validateField(this);
        });
        
        element.addEventListener('input', function() {
            if (this.classList.contains('is-invalid')) {
                validateField(this);
            }
        });
        
        // Remover classes de validação ao focar
        element.addEventListener('focus', function() {
            this.classList.remove('is-invalid');
        });
    });
}

// Validar campo individual
function validateField(field) {
    const isValid = field.checkValidity() && field.value.trim() !== '';
    
    if (isValid) {
        field.classList.remove('is-invalid');
        field.classList.add('is-valid');
    } else {
        field.classList.remove('is-valid');
        field.classList.add('is-invalid');
    }
    
    return isValid;
}

// Configurar envio do formulário
function setupFormSubmission() {
    const form = document.getElementById('uploadForm');
    
    if (!form) return;
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        handleFormSubmission();
    });
}

// Processar envio do formulário
function handleFormSubmission() {
    const formData = collectFormData();
    
    // Validar dados
    if (!validateFormData(formData)) {
        return;
    }
    
    // Simular envio
    submitDocument(formData);
}

// Coletar dados do formulário
function collectFormData() {
    return {
        title: document.getElementById('docTitle')?.value.trim() || '',
        description: document.getElementById('docDesc')?.value.trim() || '',
        category: document.getElementById('docCategory')?.value || '',
        level: document.getElementById('docLevel')?.value || '',
        allowDownload: document.getElementById('allowDownload')?.checked || false,
        file: selectedFile
    };
}

// Validar dados do formulário
function validateFormData(data) {
    let isValid = true;
    
    // Validar título
    if (!data.title) {
        showAlert('Por favor, insira o título do documento.', 'error');
        document.getElementById('docTitle')?.focus();
        isValid = false;
    }
    
    // Validar categoria
    if (!data.category) {
        showAlert('Por favor, selecione uma categoria.', 'error');
        document.getElementById('docCategory')?.focus();
        isValid = false;
    }
    
    // Validar arquivo
    if (!data.file) {
        showAlert('Por favor, selecione um arquivo.', 'error');
        isValid = false;
    }
    
    return isValid;
}

// Enviar documento
function submitDocument(formData) {
    const form = document.getElementById('uploadForm');
    const successMessage = document.getElementById('successMessage');
    
    if (!form || !successMessage) return;
    
    // Desabilitar botão de envio
    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="material-icons">hourglass_empty</span> Enviando...';
    }
    
    // Simular tempo de processamento
    setTimeout(() => {
        // Esconder formulário e mostrar sucesso
        form.style.display = 'none';
        successMessage.style.display = 'block';
        
        // Log dos dados para debug (remover em produção)
        console.log('Dados enviados:', formData);
        
        // Em produção, enviar para o backend:
        // sendToBackend(formData);
        
        // Redirecionar após sucesso
        setTimeout(() => {
            window.location.href = "repositorio.html";
        }, 2500);
        
    }, 1500);
}

// Função para envio real ao backend (implementar conforme necessário)
function sendToBackend(formData) {
    const formDataObj = new FormData();
    
    formDataObj.append('title', formData.title);
    formDataObj.append('description', formData.description);
    formDataObj.append('category', formData.category);
    formDataObj.append('level', formData.level);
    formDataObj.append('allowDownload', formData.allowDownload);
    formDataObj.append('file', formData.file);
    
    fetch('/api/upload-document', {
        method: 'POST',
        body: formDataObj,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccessMessage();
        } else {
            showAlert(data.message || 'Erro ao enviar documento.', 'error');
        }
    })
    .catch(error => {
        console.error('Erro no envio:', error);
        showAlert('Erro de conexão. Tente novamente.', 'error');
    });
}

// Mostrar mensagem de sucesso
function showSuccessMessage() {
    const form = document.getElementById('uploadForm');
    const successMessage = document.getElementById('successMessage');
    
    if (form && successMessage) {
        form.style.display = 'none';
        successMessage.style.display = 'block';
        
        setTimeout(() => {
            window.location.href = "repositorio.html";
        }, 2500);
    }
}

// Mostrar alertas personalizados
function showAlert(message, type = 'info') {
    // Remover alertas anteriores
    const existingAlert = document.querySelector('.custom-alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    // Criar novo alerta
    const alert = document.createElement('div');
    alert.className = `custom-alert alert-${type}`;
    
    // Definir ícone baseado no tipo
    let icon = 'info';
    if (type === 'error') icon = 'error';
    if (type === 'success') icon = 'check_circle';
    if (type === 'warning') icon = 'warning';
    
    alert.innerHTML = `
        <div class="alert-content">
            <span class="material-icons alert-icon">${icon}</span>
            <span class="alert-message">${message}</span>
            <button class="alert-close" onclick="closeAlert(this)">
                <span class="material-icons">close</span>
            </button>
        </div>
    `;
    
    // Adicionar estilos dinâmicos
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        max-width: 400px;
        padding: 16px;
        border-radius: 12px;
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        animation: slideInRight 0.3s ease;
        font-family: 'Segoe UI', sans-serif;
        ${getAlertStyles(type)}
    `;
    
    // Adicionar ao DOM
    document.body.appendChild(alert);
    
    // Auto remover após 5 segundos
    setTimeout(() => {
        if (alert.parentNode) {
            closeAlert(alert.querySelector('.alert-close'));
        }
    }, 5000);
}

// Obter estilos do alerta baseado no tipo
function getAlertStyles(type) {
    const styles = {
        info: 'background: #e3f2fd; border: 1px solid #2196f3; color: #1976d2;',
        success: 'background: #e8f5e8; border: 1px solid #4caf50; color: #2e7d32;',
        error: 'background: #ffebee; border: 1px solid #f44336; color: #c62828;',
        warning: 'background: #fff3e0; border: 1px solid #ff9800; color: #ef6c00;'
    };
    
    return styles[type] || styles.info;
}

// Fechar alerta
function closeAlert(button) {
    const alert = button.closest('.custom-alert');
    if (alert) {
        alert.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            if (alert.parentNode) {
                alert.remove();
            }
        }, 300);
    }
}

// Adicionar estilos CSS para os alertas
function addAlertStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .custom-alert .alert-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .custom-alert .alert-icon {
            font-size: 24px;
            flex-shrink: 0;
        }
        
        .custom-alert .alert-message {
            flex-grow: 1;
            font-weight: 500;
            font-size: 14px;
            line-height: 1.4;
        }
        
        .custom-alert .alert-close {
            background: none;
            border: none;
            cursor: pointer;
            padding: 4px;
            border-radius: 50%;
            transition: background-color 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .custom-alert .alert-close:hover {
            background-color: rgba(0, 0, 0, 0.1);
        }
        
        .custom-alert .alert-close .material-icons {
            font-size: 18px;
        }
        
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
}

// Utilitários adicionais
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function getFileIcon(filename) {
    const extension = filename.split('.').pop().toLowerCase();
    const icons = {
        pdf: '📄',
        doc: '📘',
        docx: '📘',
        ppt: '📊',
        pptx: '📊',
        default: '📎'
    };
    
    return icons[extension] || icons.default;
}

// Melhorar exibição das informações do arquivo
function enhanceFileInfo(file) {
    const fileName = document.getElementById('fileName');
    if (fileName) {
        const icon = getFileIcon(file.name);
        const size = formatFileSize(file.size);
        fileName.innerHTML = `${icon} ${file.name} <small class="text-muted">(${size})</small>`;
    }
}

// Atualizar função displayFileInfo para usar melhorias
function displayFileInfo(file) {
    const fileInfo = document.getElementById('fileInfo');
    const uploadArea = document.querySelector('.file-upload-area');
    const fileInput = document.getElementById('docFile');
    
    if (fileInfo && uploadArea) {
        enhanceFileInfo(file);
        fileInfo.style.display = 'flex';
        uploadArea.style.display = 'none';
        
        // Adicionar classe de validação
        fileInput.classList.remove('is-invalid');
        fileInput.classList.add('is-valid');
    }
}

// Inicializar estilos dos alertas quando a página carregar
document.addEventListener('DOMContentLoaded', function() {
    addAlertStyles();
});

// Função para resetar formulário (útil para testes)
function resetForm() {
    const form = document.getElementById('uploadForm');
    if (form) {
        form.reset();
        removeFile();
        
        // Remover classes de validação
        form.querySelectorAll('.is-valid, .is-invalid').forEach(element => {
            element.classList.remove('is-valid', 'is-invalid');
        });
        
        // Mostrar formulário e esconder mensagem de sucesso
        form.style.display = 'block';
        const successMessage = document.getElementById('successMessage');
        if (successMessage) {
            successMessage.style.display = 'none';
        }
    }
}

// Função para debug (remover em produção)
function debugFormData() {
    const formData = collectFormData();
    console.log('Dados atuais do formulário:', formData);
    return formData;
}