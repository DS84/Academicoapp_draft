/**
 * Suporte Profissional - JavaScript
 * AcademicoApp v1.0
 */

// ==================== Configuração ====================
const CONFIG = {
  emailEndpoint: 'https://api.academicapp.com/suporte/profissional', // Endpoint fictício
  storageKey: 'profissional_suporte_data',
  animationDuration: 2000,
  counterSpeed: 50
};

// ==================== Inicialização ====================
document.addEventListener('DOMContentLoaded', function() {
  initializeForm();
  initializeTheme();
  setupEventListeners();
  loadSavedData();
  initializeAnimations();
  animateCounters();
  setupCareerTools();
});

// ==================== Formulário ====================
function initializeForm() {
  const form = document.getElementById('careerForm');
  if (!form) return;

  // Bootstrap validation
  form.addEventListener('submit', function(event) {
    event.preventDefault();
    event.stopPropagation();

    if (form.checkValidity()) {
      handleFormSubmit();
    }

    form.classList.add('was-validated');
  }, false);
}

function handleFormSubmit() {
  const formData = collectFormData();
  
  // Validações adicionais
  if (!validateFormData(formData)) {
    return;
  }
  
  // Simular loading
  showLoading(true);
  
  // Simular envio
  setTimeout(() => {
    // Salvar dados
    saveFormData(formData);
    
    // Análise de perfil
    const profile = analyzeCareerProfile(formData);
    
    // Mostrar sucesso com recomendações
    showSuccessMessage(profile);
    
    // Limpar formulário
    resetForm();
    
    // Esconder loading
    showLoading(false);
    
    // Log para desenvolvimento
    console.log('Dados do formulário:', formData);
    console.log('Análise de perfil:', profile);
    
  }, 1500);
}

function collectFormData() {
  return {
    goal: document.getElementById('goal').value,
    experience: document.getElementById('experience').value,
    area: document.getElementById('area').value,
    urgencia: document.getElementById('urgencia').value,
    detalhes: document.getElementById('detalhes').value,
    timestamp: new Date().toISOString(),
    page: 'profissional'
  };
}

function validateFormData(data) {
  // Validações específicas
  const restrictedAreas = ['área restrita', 'teste', 'admin'];
  if (restrictedAreas.some(term => data.area.toLowerCase().includes(term))) {
    showError('Por favor, insira uma área válida.');
    return false;
  }
  
  return true;
}

function saveFormData(data) {
  try {
    const existing = localStorage.getItem(CONFIG.storageKey);
    const allData = existing ? JSON.parse(existing) : [];
    allData.push(data);
    localStorage.setItem(CONFIG.storageKey, JSON.stringify(allData));
  } catch (e) {
    console.error('Erro ao salvar dados:', e);
  }
}

function loadSavedData() {
  try {
    const saved = localStorage.getItem(CONFIG.storageKey);
    if (saved) {
      const data = JSON.parse(saved);
      console.log(`${data.length} solicitações profissionais anteriores encontradas`);
      
      // Análise de tendências
      analyzeTrends(data);
    }
  } catch (e) {
    console.error('Erro ao carregar dados:', e);
  }
}

// ==================== Análise de Carreira ====================
function analyzeCareerProfile(data) {
  const profiles = {
    curriculo: {
      servicos: ['Revisão de CV', 'Otimização ATS', 'Design profissional'],
      tempo: '48 horas',
      prioridade: data.urgencia === 'imediato' ? 'Alta' : 'Normal'
    },
    entrevista: {
      servicos: ['Simulação 1:1', 'Feedback detalhado', 'Técnicas comportamentais'],
      tempo: '3-5 dias',
      prioridade: data.urgencia === 'imediato' ? 'Urgente' : 'Normal'
    },
    mentoria: {
      servicos: ['Plano de carreira', 'Sessões semanais', 'Networking'],
      tempo: 'Programa de 1 mês',
      prioridade: 'Planejada'
    },
    networking: {
      servicos: ['Eventos exclusivos', 'Conexões direcionadas', 'LinkedIn otimizado'],
      tempo: 'Contínuo',
      prioridade: 'Estratégica'
    },
    transicao: {
      servicos: ['Análise de mercado', 'Requalificação', 'Coaching intensivo'],
      tempo: 'Programa de 3 meses',
      prioridade: 'Estruturada'
    },
    linkedin: {
      servicos: ['Otimização de perfil', 'Estratégia de conteúdo', 'Networking digital'],
      tempo: '1 semana',
      prioridade: 'Normal'
    },
    portfolio: {
      servicos: ['Design de portfólio', 'Curadoria de projetos', 'Presença online'],
      tempo: '2 semanas',
      prioridade: 'Criativa'
    }
  };
  
  return profiles[data.goal] || profiles.mentoria;
}

function analyzeTrends(data) {
  // Análise simples de tendências
  const goals = data.map(d => d.goal);
  const goalCounts = goals.reduce((acc, goal) => {
    acc[goal] = (acc[goal] || 0) + 1;
    return acc;
  }, {});
  
  const mostCommon = Object.entries(goalCounts)
    .sort((a, b) => b[1] - a[1])[0];
  
  if (mostCommon) {
    console.log(`Objetivo mais procurado: ${mostCommon[0]} (${mostCommon[1]} solicitações)`);
  }
}

// ==================== UI Feedback ====================
function showSuccessMessage(profile) {
  const successMsg = document.getElementById('successMessage');
  if (successMsg) {
    // Adicionar detalhes do perfil
    let detailsHTML = '<strong>Próximos passos:</strong><ul class="mt-2 mb-0">';
    profile.servicos.forEach(servico => {
      detailsHTML += `<li>${servico}</li>`;
    });
    detailsHTML += '</ul>';
    detailsHTML += `<p class="mb-0 mt-2"><strong>Tempo estimado:</strong> ${profile.tempo}</p>`;
    
    successMsg.innerHTML = `
      <i class="fas fa-check-circle me-2"></i>
      Solicitação enviada! Um especialista entrará em contato em até 24h.
      <div class="mt-3">${detailsHTML}</div>
    `;
    
    successMsg.classList.remove('d-none');
    successMsg.scrollIntoView({ behavior: 'smooth', block: 'center' });
    
    // Auto-hide após 15 segundos
    setTimeout(() => {
      successMsg.classList.add('d-none');
    }, 15000);
  }
}

function showError(message) {
  // Criar toast de erro
  const toast = document.createElement('div');
  toast.className = 'alert alert-danger position-fixed top-0 end-0 m-3';
  toast.style.zIndex = '9999';
  toast.innerHTML = `
    <i class="fas fa-exclamation-triangle me-2"></i>
    ${message}
  `;
  
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, 5000);
}

function showLoading(show) {
  const btn = document.querySelector('button[type="submit"]');
  if (!btn) return;
  
  if (show) {
    btn.disabled = true;
    btn.innerHTML = '<span class="loading-spinner me-2"></span>Processando...';
  } else {
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-paper-plane me-2"></i>Solicitar Suporte';
  }
}

function resetForm() {
  const form = document.getElementById('careerForm');
  if (form) {
    form.reset();
    form.classList.remove('was-validated');
  }
}

// ==================== Contadores Animados ====================
function animateCounters() {
  const counters = document.querySelectorAll('.stat-number');
  const speed = CONFIG.counterSpeed;
  
  const observerOptions = {
    threshold: 0.5
  };
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const counter = entry.target;
        const target = +counter.getAttribute('data-target');
        const increment = target / speed;
        
        const updateCount = () => {
          const current = +counter.innerText;
          
          if (current < target) {
            counter.innerText = Math.ceil(current + increment);
            setTimeout(updateCount, 30);
          } else {
            counter.innerText = target;
          }
        };
        
        updateCount();
        observer.unobserve(counter);
      }
    });
  }, observerOptions);
  
  counters.forEach(counter => {
    observer.observe(counter);
  });
}

// ==================== Event Listeners ====================
function setupEventListeners() {
  // Objetivo profissional - mostrar dicas
  const goalSelect = document.getElementById('goal');
  if (goalSelect) {
    goalSelect.addEventListener('change', function() {
      showCareerTips(this.value);
    });
  }
  
  // Nível de experiência - ajustar recomendações
  const experienceSelect = document.getElementById('experience');
  if (experienceSelect) {
    experienceSelect.addEventListener('change', function() {
      adjustRecommendations(this.value);
    });
  }
  
  // Área de interesse - sugestões automáticas
  const areaInput = document.getElementById('area');
  if (areaInput) {
    areaInput.addEventListener('input', debounce(function() {
      suggestAreas(this.value);
    }, 300));
  }
}

function showCareerTips(goal) {
  const tips = {
    curriculo: 'Dica: Use palavras-chave relevantes para sua área e mantenha o CV com no máximo 2 páginas.',
    entrevista: 'Dica: Prepare exemplos concretos usando o método STAR (Situação, Tarefa, Ação, Resultado).',
    mentoria: 'Dica: Defina objetivos claros de carreira para aproveitar melhor as sessões de mentoria.',
    networking: 'Dica: Participe ativamente de eventos e mantenha contato regular com sua rede.',
    transicao: 'Dica: Identifique habilidades transferíveis e invista em capacitação direcionada.',
    linkedin: 'Dica: Poste conteúdo relevante regularmente e interaja com publicações da sua área.',
    portfolio: 'Dica: Destaque seus melhores projetos e mantenha o portfólio atualizado.'
  };
  
  const tip = tips[goal];
  if (tip) {
    console.log(tip);
    // Poderia mostrar em um tooltip ou elemento da página
  }
}

function adjustRecommendations(experience) {
  const recommendations = {
    estudante: ['Estágios', 'Projetos acadêmicos', 'Certificações básicas'],
    recem_formado: ['Trainee programs', 'Networking ativo', 'Primeira experiência'],
    junior: ['Especialização', 'Projetos desafiadores', 'Mentoria'],
    pleno: ['Liderança', 'MBA', 'Gestão de projetos'],
    senior: ['Consultoria', 'Palestras', 'Mentoring reverso'],
    gestor: ['Executive coaching', 'Board readiness', 'Estratégia']
  };
  
  const recs = recommendations[experience];
  if (recs) {
    console.log('Recomendações para seu nível:', recs);
  }
}

function suggestAreas(input) {
  const areas = [
    'Tecnologia da Informação',
    'Marketing Digital',
    'Recursos Humanos',
    'Finanças e Controladoria',
    'Vendas e Comercial',
    'Engenharia',
    'Saúde e Bem-estar',
    'Educação',
    'Direito',
    'Administração',
    'Logística',
    'Design e Criação',
    'Comunicação',
    'Consultoria',
    'Empreendedorismo'
  ];
  
  const suggestions = areas.filter(area => 
    area.toLowerCase().includes(input.toLowerCase())
  );
  
  if (suggestions.length > 0) {
    console.log('Sugestões:', suggestions);
    // Poderia mostrar em um dropdown de sugestões
  }
}

// ==================== Ferramentas de Carreira ====================
function setupCareerTools() {
  // Calculadora de salário
  const salaryCalculator = {
    junior: { min: 1500000, max: 3000000 }, // Em Kwanzas
    pleno: { min: 3000000, max: 5000000 },
    senior: { min: 5000000, max: 10000000 }
  };
  
  // Analisador de CV (simulado)
  window.analyzeCV = function(text) {
    const keywords = ['experiência', 'resultados', 'liderança', 'projeto', 'gestão'];
    const score = keywords.reduce((acc, keyword) => {
      return acc + (text.toLowerCase().includes(keyword) ? 20 : 0);
    }, 0);
    
    return {
      score: Math.min(score, 100),
      feedback: score >= 80 ? 'Excelente!' : score >= 60 ? 'Bom' : 'Precisa melhorar'
    };
  };
}

// ==================== Tema ====================
function initializeTheme() {
  const savedTheme = localStorage.getItem('theme');
  const themeToggle = document.getElementById('themeToggle');
  
  if (savedTheme === 'dark') {
    document.body.classList.add('dark-mode');
    if (themeToggle) {
      const icon = themeToggle.querySelector('i');
      icon.className = 'fa-solid fa-sun';
    }
  }
  
  if (themeToggle) {
    themeToggle.addEventListener('click', toggleTheme);
  }
}

function toggleTheme() {
  const body = document.body;
  const themeToggle = document.getElementById('themeToggle');
  const isDark = body.classList.toggle('dark-mode');
  
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  
  if (themeToggle) {
    const icon = themeToggle.querySelector('i');
    icon.className = isDark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
  }
}

// ==================== Animações ====================
function initializeAnimations() {
  // Parallax suave nas shapes
  document.addEventListener('mousemove', (e) => {
    const shapes = document.querySelectorAll('.shape');
    const x = e.clientX / window.innerWidth;
    const y = e.clientY / window.innerHeight;
    
    shapes.forEach((shape, index) => {
      const speed = (index + 1) * 10;
      const xPos = (x - 0.5) * speed;
      const yPos = (y - 0.5) * speed;
      
      shape.style.transform = `translate(${xPos}px, ${yPos}px)`;
    });
  });
  
  // Observador para cards
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  };
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, observerOptions);
  
  document.querySelectorAll('.testimonial-card').forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = 'all 0.6s ease';
    observer.observe(card);
  });
}

// ==================== Utilidades ====================
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

function formatCurrency(value) {
  return new Intl.NumberFormat('pt-AO', {
    style: 'currency',
    currency: 'AOA'
  }).format(value);
}

function getDaysUntil(dateString) {
  const target = new Date(dateString);
  const today = new Date();
  const diff = target - today;
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

// ==================== API (Simulada) ====================
async function sendToServer(data) {
  try {
    // Em produção, fazer requisição real
    const response = await fetch(CONFIG.emailEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data)
    });
    
    if (!response.ok) {
      throw new Error('Erro ao enviar dados');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Erro:', error);
    saveFormData(data);
  }
}

// ==================== Exportar para uso externo ====================
window.ProfessionalSupport = {
  resetForm,
  collectFormData,
  analyzeCareerProfile,
  formatCurrency,
  analyzeCV
};