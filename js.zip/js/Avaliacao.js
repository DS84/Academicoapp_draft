/**
 * Sistema de Avaliação Institucional
 * AcademicoApp - Versão 3.0
 */

// ================== Configuração da Metodologia ==================
const METODOLOGIA = [
  {
    nome: "Qualidade de Ensino",
    peso: 30,
    icon: "fas fa-graduation-cap",
    itens: [
      {
        chave: "ratio_estudante_professor",
        rotulo: "Ratio estudante/professor",
        dica: "Relação média alunos/docente - ideal entre 10:1 e 20:1"
      },
      {
        chave: "qualificacao_docente",
        rotulo: "Qualificações do corpo docente",
        dica: "Titulação (mestrado/doutorado), experiência, formação contínua"
      },
      {
        chave: "taxa_conclusao",
        rotulo: "Taxa de conclusão de cursos",
        dica: "Percentual de alunos que concluem no tempo previsto"
      }
    ]
  },
  {
    nome: "Investigação",
    peso: 25,
    icon: "fas fa-microscope",
    itens: [
      {
        chave: "publicacoes",
        rotulo: "Publicações científicas",
        dica: "Qualidade das revistas, indexação e volume de publicações"
      },
      {
        chave: "projetos",
        rotulo: "Projetos de investigação",
        dica: "Projetos ativos, financiamento obtido, resultados práticos"
      },
      {
        chave: "parcerias",
        rotulo: "Parcerias internacionais",
        dica: "Redes de pesquisa, consórcios e cooperação internacional"
      }
    ]
  },
  {
    nome: "Empregabilidade",
    peso: 20,
    icon: "fas fa-briefcase",
    itens: [
      {
        chave: "taxa_emprego",
        rotulo: "Taxa de emprego dos graduados",
        dica: "Inserção no mercado de trabalho até 6 meses após formatura"
      },
      {
        chave: "parcerias_empresa",
        rotulo: "Parcerias com empresas",
        dica: "Acordos de cooperação, projetos conjuntos, eventos empresariais"
      },
      {
        chave: "estagios",
        rotulo: "Programas de estágio",
        dica: "Cobertura, qualidade e supervisão dos estágios curriculares"
      }
    ]
  },
  {
    nome: "Infraestrutura",
    peso: 15,
    icon: "fas fa-building",
    itens: [
      {
        chave: "instalacoes",
        rotulo: "Instalações modernas",
        dica: "Salas de aula, acessibilidade, segurança e conforto"
      },
      {
        chave: "recursos_ti",
        rotulo: "Recursos tecnológicos",
        dica: "Laboratórios de TI, conectividade, software e hardware"
      },
      {
        chave: "bibliotecas",
        rotulo: "Bibliotecas e laboratórios",
        dica: "Acervo atualizado, equipamentos especializados, horários"
      }
    ]
  },
  {
    nome: "Reputação e Impacto Social",
    peso: 10,
    icon: "fas fa-award",
    itens: [
      {
        chave: "reconhecimento",
        rotulo: "Reconhecimento nacional e internacional",
        dica: "Premiações, rankings, visibilidade e prestígio"
      },
      {
        chave: "extensao",
        rotulo: "Projetos de extensão comunitária",
        dica: "Cobertura, impacto social e continuidade dos projetos"
      },
      {
        chave: "diversidade",
        rotulo: "Diversidade e inclusão",
        dica: "Equidade de gênero, acessibilidade e políticas inclusivas"
      }
    ]
  }
];

// ================== Base de Dados de Instituições ==================
const SEED_INSTITUICOES = [
  // LUANDA
  { nome: "Universidade Agostinho Neto (UAN)", tipo: "Universidade", provincia: "Luanda" },
  { nome: "Universidade Católica de Angola (UCAN)", tipo: "Universidade", provincia: "Luanda" },
  { nome: "Universidade Óscar Ribas (UOR)", tipo: "Universidade", provincia: "Luanda" },
  { nome: "Universidade Independente de Angola (UNIA)", tipo: "Universidade", provincia: "Luanda" },
  { nome: "ISPTEC – Inst. Sup. Politécnico de Tecnologias e Ciências", tipo: "Instituto Médio/Superior", provincia: "Luanda" },
  { nome: "ISCED Luanda – Ciências da Educação", tipo: "Instituto Médio/Superior", provincia: "Luanda" },
  { nome: "ISPOCA – Instituto Superior Politécnico Cazenga", tipo: "Instituto Médio/Superior", provincia: "Luanda" },
  { nome: "IMIL – Instituto Médio Industrial de Luanda", tipo: "Centro Técnico/Profissional", provincia: "Luanda" },
  { nome: "CENFOC – Centro de Formação de Jornalistas", tipo: "Centro Técnico/Profissional", provincia: "Luanda" },
  { nome: "CENFFOR/INEFOP – Viana", tipo: "Centro Técnico/Profissional", provincia: "Luanda" },

  // BENGUELA
  { nome: "Universidade Katyavala Bwila (UKB)", tipo: "Universidade", provincia: "Benguela" },
  { nome: "ISCED Benguela – Ciências da Educação", tipo: "Instituto Médio/Superior", provincia: "Benguela" },
  { nome: "Instituto Superior Politécnico da Catumbela", tipo: "Instituto Médio/Superior", provincia: "Benguela" },
  { nome: "Centro de Formação Profissional de Benguela (INEFOP)", tipo: "Centro Técnico/Profissional", provincia: "Benguela" },

  // HUÍLA
  { nome: "Universidade Mandume ya Ndemufayo (UMN)", tipo: "Universidade", provincia: "Huíla" },
  { nome: "ISCED Huíla – Ciências da Educação", tipo: "Instituto Médio/Superior", provincia: "Huíla" },
  { nome: "Instituto Superior Politécnico da Huíla", tipo: "Instituto Médio/Superior", provincia: "Huíla" },
  { nome: "Centro de Formação Profissional da Huíla (INEFOP)", tipo: "Centro Técnico/Profissional", provincia: "Huíla" },

  // HUAMBO
  { nome: "Universidade José Eduardo dos Santos (UJES)", tipo: "Universidade", provincia: "Huambo" },
  { nome: "ISCED Huambo – Ciências da Educação", tipo: "Instituto Médio/Superior", provincia: "Huambo" },
  { nome: "Centro de Formação Profissional do Huambo (INEFOP)", tipo: "Centro Técnico/Profissional", provincia: "Huambo" },

  // KWANZA SUL
  { nome: "Universidade 11 de Novembro – Polo Sumbe", tipo: "Universidade", provincia: "Kwanza Sul" },
  { nome: "Instituto Superior Politécnico do Kwanza Sul", tipo: "Instituto Médio/Superior", provincia: "Kwanza Sul" },
  { nome: "Centro de Formação Profissional do Sumbe (INEFOP)", tipo: "Centro Técnico/Profissional", provincia: "Kwanza Sul" },

  // CABINDA
  { nome: "Universidade 11 de Novembro (UON)", tipo: "Universidade", provincia: "Cabinda" },
  { nome: "Instituto Superior Politécnico de Cabinda", tipo: "Instituto Médio/Superior", provincia: "Cabinda" },
  { nome: "Centro de Formação Profissional de Cabinda", tipo: "Centro Técnico/Profissional", provincia: "Cabinda" },

  // UÍGE
  { nome: "Universidade Kimpa Vita (UKV)", tipo: "Universidade", provincia: "Uíge" },
  { nome: "ISCED Uíge", tipo: "Instituto Médio/Superior", provincia: "Uíge" },

  // MALANJE
  { nome: "Universidade Lueji A'Nkonde", tipo: "Universidade", provincia: "Malanje" },
  { nome: "Instituto Superior Politécnico de Malanje", tipo: "Instituto Médio/Superior", provincia: "Malanje" },

  // LUNDA NORTE
  { nome: "Universidade Lueji A'Nkonde – Pólo Dundo", tipo: "Universidade", provincia: "Lunda Norte" },
  { nome: "Instituto Superior Politécnico do Dundo", tipo: "Instituto Médio/Superior", provincia: "Lunda Norte" },

  // LUNDA SUL
  { nome: "Instituto Superior Politécnico de Saurimo", tipo: "Instituto Médio/Superior", provincia: "Lunda Sul" },
  { nome: "Centro de Formação Profissional de Saurimo", tipo: "Centro Técnico/Profissional", provincia: "Lunda Sul" }
];

// ================== Gestão de Persistência (localStorage) ==================
const LS_KEY = "instituicoesAval_v3";

function getInstituicoes() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch (e) {
    console.error("Erro ao carregar instituições:", e);
    return [];
  }
}

function saveInstituicoes(arr) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(arr));
  } catch (e) {
    console.error("Erro ao salvar instituições:", e);
  }
}

function seedInstituicoes() {
  const existentes = getInstituicoes();
  if (existentes.length === 0) {
    saveInstituicoes(SEED_INSTITUICOES);
  }
}

// ================== Funções de UI ==================
function loadSelectInstituicao() {
  const tipo = document.getElementById("tipo-select").value;
  const sel = document.getElementById("instituicao-select");
  sel.innerHTML = "";

  if (!tipo) {
    sel.innerHTML = `<option value="" selected disabled>Selecione o tipo antes...</option>`;
    return;
  }

  const lista = getInstituicoes()
    .filter(i => i.tipo === tipo)
    .sort((a, b) => a.nome.localeCompare(b.nome));

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = "Selecione a instituição...";
  placeholder.disabled = true;
  placeholder.selected = true;
  sel.appendChild(placeholder);

  lista.forEach(({ nome }) => {
    const opt = document.createElement("option");
    opt.value = nome;
    opt.textContent = nome;
    sel.appendChild(opt);
  });
}

function addInstituicao(nome, tipo, provincia = "") {
  const trimmed = (nome || "").trim();
  if (!trimmed || !tipo) return false;
  
  const lista = getInstituicoes();
  const existe = lista.some(i => i.nome === trimmed && i.tipo === tipo);
  
  if (!existe) {
    lista.push({ nome: trimmed, tipo, provincia });
    saveInstituicoes(lista);
  }
  
  if (document.getElementById("tipo-select").value === tipo) {
    loadSelectInstituicao();
  }
  
  const sel = document.getElementById("instituicao-select");
  if (sel && document.getElementById("tipo-select").value === tipo) {
    sel.value = trimmed;
  }
  
  return true;
}

function removeInstituicaoSelecionada() {
  const tipo = document.getElementById("tipo-select").value;
  const nome = document.getElementById("instituicao-select").value;
  
  if (!tipo || !nome) {
    showToast("Selecione uma instituição para remover", "warning");
    return;
  }
  
  if (confirm(`Tem certeza que deseja remover "${nome}"?`)) {
    const lista = getInstituicoes().filter(i => !(i.tipo === tipo && i.nome === nome));
    saveInstituicoes(lista);
    loadSelectInstituicao();
    showToast("Instituição removida com sucesso", "success");
  }
}

// ================== Renderização do Formulário ==================
function renderFormulario() {
  const form = document.getElementById("avaliacao-form");
  form.innerHTML = "";

  METODOLOGIA.forEach((dim, idx) => {
    const card = document.createElement("div");
    card.className = "dimension-card";
    card.innerHTML = `
      <div class="dimension-header">
        <div class="dimension-title">
          <i class="${dim.icon}"></i>
          ${dim.nome}
        </div>
        <span class="dimension-weight">Peso: ${dim.peso}%</span>
      </div>
      <div class="dimension-body">
        <div class="row g-3" id="grid-${idx}"></div>
        <div class="dimension-average" id="media_${idx}">
          Média: —
        </div>
      </div>
    `;
    form.appendChild(card);

    const grid = card.querySelector(`#grid-${idx}`);

    dim.itens.forEach((item) => {
      const col = document.createElement("div");
      col.className = "col-12";
      col.innerHTML = `
        <div class="row align-items-center gy-2">
          <div class="col-md-6">
            <label class="form-label fw-semibold mb-0" for="${item.chave}"
                   data-bs-toggle="tooltip" data-bs-placement="top" 
                   title="${item.dica}">
              ${item.rotulo}
            </label>
          </div>
          <div class="col-md-6">
            <div class="btn-group crit-group" role="group" 
                 data-crit="${item.chave}" 
                 aria-label="${item.rotulo}">
              ${[1, 2, 3, 4, 5].map(v => `
                <input type="radio" class="btn-check" 
                       name="${item.chave}" 
                       id="${item.chave}_${v}" 
                       value="${v}">
                <label class="btn btn-outline-secondary" 
                       for="${item.chave}_${v}">${v}</label>
              `).join("")}
            </div>
          </div>
        </div>
      `;
      grid.appendChild(col);
    });
  });

  // Inicializar tooltips do Bootstrap
  const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
  [...tooltipTriggerList].forEach(el => new bootstrap.Tooltip(el));
}

// ================== Validação ==================
function critSelecionado(name) {
  return !!document.querySelector(`input[name="${name}"]:checked`);
}

function validarTodosCriterios() {
  const faltantes = [];
  
  METODOLOGIA.forEach(dim => {
    dim.itens.forEach(it => {
      const group = document.querySelector(`.crit-group[data-crit="${it.chave}"]`);
      const ok = critSelecionado(it.chave);
      
      group.classList.toggle("crit-pendente", !ok);
      
      if (!ok) {
        faltantes.push({ chave: it.chave, el: group });
      }
    });
  });
  
  if (faltantes.length > 0) {
    faltantes[0].el.scrollIntoView({ behavior: "smooth", block: "center" });
  }
  
  return faltantes.length === 0;
}

// ================== Cálculos ==================
function obterValor(name) {
  const sel = document.querySelector(`input[name="${name}"]:checked`);
  return sel ? Number(sel.value) : null;
}

function calcular() {
  // Validar tipo e instituição
  const tipoSel = document.getElementById("tipo-select");
  const instSel = document.getElementById("instituicao-select");
  
  if (!tipoSel.value) {
    tipoSel.classList.add("is-invalid");
    tipoSel.focus();
    showToast("Selecione o tipo de instituição", "danger");
    return;
  } else {
    tipoSel.classList.remove("is-invalid");
  }
  
  if (!instSel.value) {
    instSel.classList.add("is-invalid");
    instSel.focus();
    showToast("Selecione a instituição a avaliar", "danger");
    return;
  } else {
    instSel.classList.remove("is-invalid");
  }

  // Validar todos os critérios
  if (!validarTodosCriterios()) {
    showToast("Preencha todos os 15 subcritérios antes de calcular", "danger");
    return;
  }

  showLoadingOverlay(true);
  
  setTimeout(() => {
    let totalPonderado = 0;

    METODOLOGIA.forEach((dim, idx) => {
      const valores = dim.itens.map(it => obterValor(it.chave));
      const media = valores.reduce((a, b) => a + b, 0) / valores.length;
      const score0a100 = ((media - 1) / 4) * 100;

      document.getElementById(`media_${idx}`).innerHTML = `
        <i class="fas fa-chart-line me-2"></i>
        Média: ${media.toFixed(2)} → ${score0a100.toFixed(1)}%
      `;

      totalPonderado += score0a100 * (dim.peso / 100);
    });

    const score = Number(totalPonderado.toFixed(1));
    const scoreGlobalEl = document.getElementById("score-global");
    const progress = document.getElementById("score-progress");
    
    scoreGlobalEl.textContent = `${score} / 100`;
    progress.style.width = `${Math.min(100, Math.max(0, score))}%`;
    
    // Animar o progresso
    progress.style.transition = "width 0.8s ease";
    
    showLoadingOverlay(false);
    showToast(`Avaliação calculada: ${score}/100 - ${getScoreLabel(score)}`, "success");
  }, 500);
}

function getScoreLabel(score) {
  if (score >= 85) return "Excelente";
  if (score >= 70) return "Bom";
  if (score >= 50) return "Médio";
  return "Necessita Melhorias";
}

// ================== Funcionalidades Auxiliares ==================
function limpar() {
  if (!confirm("Tem certeza que deseja limpar todos os dados?")) return;
  
  // Limpar formulário
  document.getElementById("avaliacao-form").reset?.();
  document.querySelectorAll('#avaliacao-form input[type="radio"]').forEach(r => r.checked = false);
  document.getElementById("observacoes").value = "";
  
  // Resetar pontuação
  document.getElementById("score-global").textContent = "—";
  const progress = document.getElementById("score-progress");
  progress.style.width = "0%";
  
  // Resetar médias
  METODOLOGIA.forEach((_, idx) => {
    document.getElementById(`media_${idx}`).innerHTML = "Média: —";
  });
  
  // Resetar selects
  const tipoSel = document.getElementById("tipo-select");
  const instSel = document.getElementById("instituicao-select");
  tipoSel.value = "";
  instSel.innerHTML = `<option value="" selected disabled>Selecione o tipo antes...</option>`;
  tipoSel.classList.remove("is-invalid");
  instSel.classList.remove("is-invalid");
  
  // Remover realces
  document.querySelectorAll(".crit-group").forEach(g => g.classList.remove("crit-pendente"));
  
  showToast("Formulário limpo com sucesso", "info");
}

function exportarCSV() {
  const tipo = document.getElementById("tipo-select").value || "";
  const instituicao = document.getElementById("instituicao-select").value || "";
  
  if (!tipo || !instituicao) {
    showToast("Preencha a instituição antes de exportar", "warning");
    return;
  }
  
  const linhas = [];
  const data = new Date().toLocaleDateString("pt-BR");
  const hora = new Date().toLocaleTimeString("pt-BR");
  
  linhas.push(["AVALIAÇÃO INSTITUCIONAL - ACADEMICO APP"]);
  linhas.push(["Data", data]);
  linhas.push(["Hora", hora]);
  linhas.push([]);
  linhas.push(["Tipo", tipo]);
  linhas.push(["Instituição", instituicao]);
  linhas.push([]);
  linhas.push(["Dimensão", "Peso(%)", "Critério", "Valor(1-5)"]);
  
  METODOLOGIA.forEach(d => {
    d.itens.forEach(it => {
      const v = obterValor(it.chave);
      linhas.push([d.nome, d.peso, it.rotulo, v !== null ? v : ""]);
    });
  });

  const obs = document.getElementById("observacoes").value.replace(/\n/g, " ");
  const score = document.getElementById("score-global").textContent;
  
  linhas.push([]);
  linhas.push(["Observações", obs]);
  linhas.push(["Pontuação Ponderada", score]);

  const csv = linhas.map(row => row.map(cell => {
    const s = String(cell ?? "");
    if (/[",\n;]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  }).join(";")).join("\n");

  const filename = `avaliacao_${(tipo || "tipo").replace(/\s+/g, "_")}_${(instituicao || "instituicao").replace(/\s+/g, "_")}_${data.replace(/\//g, "-")}.csv`;
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  showToast("CSV exportado com sucesso", "success");
}

// ================== Utilitários de UI ==================
function showToast(msg, variant = "secondary") {
  const toastContainer = document.querySelector('.toast-container');
  
  const toastDiv = document.createElement("div");
  toastDiv.className = `toast align-items-center text-bg-${variant} border-0`;
  toastDiv.role = "alert";
  toastDiv.ariaLive = "assertive";
  toastDiv.ariaAtomic = "true";
  
  toastDiv.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">
        <i class="fas fa-${getToastIcon(variant)} me-2"></i>
        ${msg}
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Fechar"></button>
    </div>
  `;
  
  toastContainer.appendChild(toastDiv);
  
  const toast = new bootstrap.Toast(toastDiv);
  toast.show();
  
  toastDiv.addEventListener('hidden.bs.toast', () => {
    toastDiv.remove();
  });
}

function getToastIcon(variant) {
  const icons = {
    success: 'check-circle',
    danger: 'exclamation-triangle',
    warning: 'exclamation-circle',
    info: 'info-circle',
    secondary: 'bell'
  };
  return icons[variant] || 'bell';
}

function showLoadingOverlay(show) {
  const overlay = document.getElementById('loadingOverlay');
  if (overlay) {
    overlay.classList.toggle('show', show);
  }
}

// ================== Tema Dark Mode ==================
function toggleTheme() {
  const body = document.body;
  const themeToggle = document.getElementById('themeToggle');
  const isDark = body.classList.toggle('dark-mode');
  
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  
  const icon = themeToggle.querySelector('i');
  icon.className = isDark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
}

function loadTheme() {
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme === 'dark') {
    document.body.classList.add('dark-mode');
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
      const icon = themeToggle.querySelector('i');
      icon.className = 'fa-solid fa-sun';
    }
  }
}

// ================== Event Listeners ==================
function initializeEventListeners() {
  // Botões principais
  document.getElementById("btn-calcular")?.addEventListener("click", calcular);
  document.getElementById("btn-limpar")?.addEventListener("click", limpar);
  document.getElementById("btn-exportar")?.addEventListener("click", exportarCSV);
  document.getElementById("btn-remover-inst")?.addEventListener("click", removeInstituicaoSelecionada);
  
  // Tema
  document.getElementById("themeToggle")?.addEventListener("click", toggleTheme);
  
  // Filtro de instituições por tipo
  document.getElementById("tipo-select")?.addEventListener("change", () => {
    document.getElementById("tipo-select").classList.remove("is-invalid");
    loadSelectInstituicao();
    document.getElementById("instituicao-select").classList.remove("is-invalid");
  });
  
  // Remover destaque ao selecionar critério
  document.addEventListener("change", (e) => {
    if (e.target.matches('#avaliacao-form input[type="radio"]')) {
      const group = e.target.closest(".crit-group");
      if (group) {
        group.classList.remove("crit-pendente");
      }
    }
  });
  
  // Modal de nova instituição
  const formInstituicao = document.getElementById("form-instituicao");
  if (formInstituicao) {
    formInstituicao.addEventListener("submit", (e) => {
      e.preventDefault();
      
      const tipo = document.getElementById("instituicao-tipo").value;
      const nome = document.getElementById("instituicao-nome").value;
      const provincia = document.getElementById("instituicao-prov").value;
      
      if (addInstituicao(nome, tipo, provincia)) {
        const modal = bootstrap.Modal.getInstance(document.getElementById("modalInstituicao"));
        modal.hide();
        formInstituicao.reset();
        showToast("Instituição adicionada com sucesso", "success");
      } else {
        showToast("Erro ao adicionar instituição", "danger");
      }
    });
  }
  
  // Validação ao mudar instituição
  document.getElementById("instituicao-select")?.addEventListener("change", () => {
    document.getElementById("instituicao-select").classList.remove("is-invalid");
  });
}

// ================== Inicialização ==================
function init() {
  // Carregar tema
  loadTheme();
  
  // Inicializar base de dados
  seedInstituicoes();
  
  // Renderizar formulário
  renderFormulario();
  
  // Configurar event listeners
  initializeEventListeners();
  
  // Mensagem de boas-vindas
  console.log('%c🎓 Sistema de Avaliação Institucional Carregado', 'color: #667eea; font-size: 16px; font-weight: bold;');
}

// Aguardar DOM carregar
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}