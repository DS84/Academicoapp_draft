// Visualizador PDF - Academicoapp
// Variáveis globais
let pdfDoc = null;
let pageNum = 1;
let pageRendering = false;
let pageNumPending = null;
let scale = 1.2;
let rotation = 0;
let canvas = null;
let ctx = null;
let documentSize = 0;

// URL do PDF de exemplo
const pdfUrl = 'https://raw.githubusercontent.com/mozilla/pdf.js/ba2edeae/web/compressed.tracemonkey-pldi-09.pdf';

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    initializeViewer();
});

function initializeViewer() {
    setupCanvas();
    loadPDF();
    setupEventListeners();
    updateZoomDisplay();
}

// Configurar canvas
function setupCanvas() {
    canvas = document.getElementById('pdf-canvas');
    if (!canvas) {
        canvas = document.createElement('canvas');
        canvas.id = 'pdf-canvas';
        document.getElementById('pdf-container').appendChild(canvas);
    }
    ctx = canvas.getContext('2d');
}

// Carregar PDF
function loadPDF() {
    showLoading(true);
    
    const loadingTask = pdfjsLib.getDocument(pdfUrl);
    loadingTask.promise.then(function(pdfDoc_) {
        pdfDoc = pdfDoc_;
        
        // Atualizar informações do documento
        updateDocumentInfo();
        
        // Renderizar primeira página
        renderPage(pageNum);
        
        // Esconder loading
        showLoading(false);
        
        console.log('PDF carregado com sucesso:', pdfDoc.numPages, 'páginas');
        
    }).catch(function(error) {
        console.error('Erro ao carregar PDF:', error);
        showError('Erro ao carregar o documento PDF');
        showLoading(false);
    });
}

// Mostrar/ocultar loading
function showLoading(show) {
    const spinner = document.getElementById('loading-spinner');
    const canvas = document.getElementById('pdf-canvas');
    
    if (spinner) {
        spinner.style.display = show ? 'block' : 'none';
    }
    if (canvas) {
        canvas.style.display = show ? 'none' : 'block';
    }
}

// Atualizar informações do documento
function updateDocumentInfo() {
    if (!pdfDoc) return;
    
    // Atualizar contadores de páginas
    document.getElementById('page-count').textContent = pdfDoc.numPages;
    document.getElementById('total-pages').textContent = pdfDoc.numPages;
    document.getElementById('current-page').textContent = pageNum;
    document.getElementById('document-pages').textContent = pdfDoc.numPages;
    
    // Configurar input de página
    const pageInput = document.getElementById('page-input');
    if (pageInput) {
        pageInput.max = pdfDoc.numPages;
        pageInput.value = pageNum;
    }
    
    // Simular tamanho do documento
    simulateDocumentSize();
}

// Simular cálculo do tamanho do documento
function simulateDocumentSize() {
    // Estimativa baseada no número de páginas (simulação)
    const estimatedSize = pdfDoc.numPages * 150; // ~150KB por página (estimativa)
    documentSize = estimatedSize * 1024; // Converter para bytes
    
    const sizeElement = document.getElementById('document-size');
    if (sizeElement) {
        sizeElement.textContent = formatFileSize(documentSize);
    }
}

// Renderizar página
function renderPage(num) {
    if (!pdfDoc || num < 1 || num > pdfDoc.numPages) return;
    
    pageRendering = true;
    
    pdfDoc.getPage(num).then(function(page) {
        const viewport = page.getViewport({ scale: scale, rotation: rotation });
        
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        const renderContext = {
            canvasContext: ctx,
            viewport: viewport
        };
        
        const renderTask = page.render(renderContext);
        
        renderTask.promise.then(function() {
            pageRendering = false;
            
            if (pageNumPending !== null) {
                renderPage(pageNumPending);
                pageNumPending = null;
            }
            
            // Atualizar UI
            updatePageDisplay();
            updateNavigationButtons();
            
        }).catch(function(error) {
            console.error('Erro ao renderizar página:', error);
            pageRendering = false;
        });
        
    }).catch(function(error) {
        console.error('Erro ao obter página:', error);
        pageRendering = false;
    });
}

// Enfileirar renderização de página
function queueRenderPage(num) {
    if (pageRendering) {
        pageNumPending = num;
    } else {
        renderPage(num);
    }
}

// Atualizar display da página
function updatePageDisplay() {
    document.getElementById('current-page').textContent = pageNum;
    
    const pageInput = document.getElementById('page-input');
    if (pageInput) {
        pageInput.value = pageNum;
    }
}

// Atualizar botões de navegação
function updateNavigationButtons() {
    const prevBtn = document.querySelector('button[onclick="prevPage()"]');
    const nextBtn = document.querySelector('button[onclick="nextPage()"]');
    
    if (prevBtn) {
        prevBtn.disabled = pageNum <= 1;
    }
    if (nextBtn) {
        nextBtn.disabled = pageNum >= pdfDoc.numPages;
    }
}

// Navegação - página anterior
function prevPage() {
    if (pageNum <= 1) return;
    pageNum--;
    queueRenderPage(pageNum);
}

// Navegação - próxima página
function nextPage() {
    if (!pdfDoc || pageNum >= pdfDoc.numPages) return;
    pageNum++;
    queueRenderPage(pageNum);
}

// Ir para página específica
function goToPage(num) {
    const pageNumber = parseInt(num);
    if (pageNumber < 1 || pageNumber > pdfDoc.numPages) {
        showAlert('Número de página inválido', 'warning');
        document.getElementById('page-input').value = pageNum;
        return;
    }
    
    pageNum = pageNumber;
    queueRenderPage(pageNum);
}

// Controles de zoom
function zoomIn() {
    if (scale >= 3.0) {
        showAlert('Zoom máximo atingido', 'info');
        return;
    }
    scale += 0.2;
    updateZoom();
}

function zoomOut() {
    if (scale <= 0.5) {
        showAlert('Zoom mínimo atingido', 'info');
        return;
    }
    scale -= 0.2;
    updateZoom();
}

function updateZoom() {
    queueRenderPage(pageNum);
    updateZoomDisplay();
}

function updateZoomDisplay() {
    const zoomLevel = document.getElementById('zoom-level');
    if (zoomLevel) {
        zoomLevel.textContent = Math.round(scale * 100) + '%';
    }
}

// Ajustar à largura
function fitToWidth() {
    if (!pdfDoc) return;
    
    pdfDoc.getPage(pageNum).then(function(page) {
        const viewport = page.getViewport({ scale: 1 });
        const containerWidth = document.getElementById('pdf-container').clientWidth - 40; // padding
        const newScale = containerWidth / viewport.width;
        
        scale = Math.max(0.5, Math.min(3.0, newScale));
        updateZoom();
        
        showAlert('Documento ajustado à largura', 'success');
    });
}

// Girar documento
function rotateDocument() {
    rotation += 90;
    if (rotation >= 360) rotation = 0;
    
    queueRenderPage(pageNum);
    
    const rotations = ['Normal', '90°', '180°', '270°'];
    const rotationIndex = rotation / 90;
    showAlert(`Documento rotacionado: ${rotations[rotationIndex]}`, 'info');
}

// Tela cheia
function toggleFullscreen() {
    const container = document.getElementById('pdf-container');
    
    if (!document.fullscreenElement) {
        container.requestFullscreen().then(() => {
            showAlert('Modo tela cheia ativado', 'success');
        }).catch(err => {
            console.error('Erro ao entrar em tela cheia:', err);
            showAlert('Não foi possível ativar tela cheia', 'error');
        });
    } else {
        document.exitFullscreen().then(() => {
            showAlert('Modo tela cheia desativado', 'info');
        });
    }
}

// Imprimir documento
function printDocument() {
    if (!pdfDoc) {
        showAlert('Documento não carregado', 'error');
        return;
    }
    
    showAlert('Preparando documento para impressão...', 'info');
    
    // Simular preparação para impressão
    setTimeout(() => {
        window.print();
    }, 1000);
}

// Download do PDF
function downloadPDF() {
    showToast('Preparando download do documento...');
    
    // Simular download
    setTimeout(() => {
        const link = document.createElement('a');
        link.href = pdfUrl;
        link.download = 'Calculo_Diferencial_Integral.pdf';
        link.target = '_blank';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        showAlert('Download iniciado com sucesso', 'success');
    }, 1500);
}

// Voltar à página anterior
function goBack() {
    if (window.history.length > 1) {
        window.history.back();
    } else {
        window.location.href = "repositorio.html";
    }
}

// Sistema de comentários
function saveNote() {
    const noteText = document.getElementById('noteText');
    const text = noteText.value.trim();
    
    if (!text) {
        showAlert('Por favor, escreva um comentário', 'warning');
        return;
    }
    
    if (text.length > 500) {
        showAlert('Comentário muito longo (máximo 500 caracteres)', 'warning');
        return;
    }
    
    // Adicionar comentário
    addComment(text);
    
    // Limpar campo e fechar modal
    noteText.value = '';
    const modal = bootstrap.Modal.getInstance(document.getElementById('addNoteModal'));
    if (modal) {
        modal.hide();
    }
    
    showAlert('Comentário adicionado com sucesso', 'success');
}

// Adicionar comentário à lista
function addComment(text) {
    const commentsContainer = document.getElementById('comments-section');
    const commentElement = document.createElement('div');
    commentElement.className = 'comment-item';
    
    const now = new Date();
    const timeString = now.toLocaleTimeString('pt-BR', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    commentElement.innerHTML = `
        <div class="comment-header">
            <div class="comment-author">
                <div class="author-avatar">V</div>
                <span class="author-name">Você</span>
            </div>
            <span class="comment-time">Agora, ${timeString}</span>
        </div>
        <div class="comment-content">${escapeHtml(text)}</div>
        <div class="comment-actions">
            <button class="btn-like" onclick="toggleLike(this)">
                <span class="material-icons">thumb_up</span>
                <span class="like-count">0</span>
            </button>
            <button class="btn-reply" onclick="replyToComment(this)">
                <span class="material-icons">reply</span>
                Responder
            </button>
        </div>
    `;
    
    // Adicionar animação
    commentElement.style.opacity = '0';
    commentElement.style.transform = 'translateY(-20px)';
    
    commentsContainer.insertBefore(commentElement, commentsContainer.firstChild);
    
    // Animar entrada
    setTimeout(() => {
        commentElement.style.transition = 'all 0.3s ease';
        commentElement.style.opacity = '1';
        commentElement.style.transform = 'translateY(0)';
    }, 100);
}

// Toggle like em comentário
function toggleLike(button) {
    button.classList.toggle('active');
    const countElement = button.querySelector('.like-count');
    let count = parseInt(countElement.textContent);
    
    if (button.classList.contains('active')) {
        count++;
        showAlert('Curtida adicionada', 'success');
    } else {
        count--;
        showAlert('Curtida removida', 'info');
    }
    
    countElement.textContent = count;
}

// Responder a comentário (placeholder)
function replyToComment(button) {
    const commentItem = button.closest('.comment-item');
    const authorName = commentItem.querySelector('.author-name').textContent;
    
    const noteText = document.getElementById('noteText');
    noteText.value = `@${authorName} `;
    noteText.focus();
    
    // Abrir modal
    const modal = new bootstrap.Modal(document.getElementById('addNoteModal'));
    modal.show();
}

// Event listeners
function setupEventListeners() {
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.target.tagName.toLowerCase() === 'input' || 
            e.target.tagName.toLowerCase() === 'textarea') {
            return;
        }
        
        switch(e.key) {
            case 'ArrowLeft':
                e.preventDefault();
                prevPage();
                break;
            case 'ArrowRight':
                e.preventDefault();
                nextPage();
                break;
            case '+':
            case '=':
                e.preventDefault();
                zoomIn();
                break;
            case '-':
                e.preventDefault();
                zoomOut();
                break;
            case 'f':
            case 'F':
                if (e.ctrlKey) {
                    e.preventDefault();
                    toggleFullscreen();
                }
                break;
            case 'p':
            case 'P':
                if (e.ctrlKey) {
                    e.preventDefault();
                    printDocument();
                }
                break;
        }
    });
    
    // Resize listener para ajustar canvas
    window.addEventListener('resize', function() {
        if (pdfDoc && !pageRendering) {
            setTimeout(() => {
                queueRenderPage(pageNum);
            }, 100);
        }
    });
    
    // Fullscreen listener
    document.addEventListener('fullscreenchange', function() {
        setTimeout(() => {
            if (pdfDoc && !pageRendering) {
                queueRenderPage(pageNum);
            }
        }, 100);
    });
}

// Funções utilitárias
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Sistema de alertas
function showAlert(message, type = 'info') {
    const alertElement = createAlert(message, type);
    document.body.appendChild(alertElement);
    
    // Auto remover após 4 segundos
    setTimeout(() => {
        if (alertElement.parentNode) {
            removeAlert(alertElement);
        }
    }, 4000);
}

function createAlert(message, type) {
    const alert = document.createElement('div');
    alert.className = `alert-notification alert-${type}`;
    
    const icons = {
        success: 'check_circle',
        error: 'error',
        warning: 'warning',
        info: 'info'
    };
    
    const colors = {
        success: '#28a745',
        error: '#dc3545',
        warning: '#ffc107',
        info: '#17a2b8'
    };
    
    alert.innerHTML = `
        <div class="alert-content">
            <span class="material-icons">${icons[type] || 'info'}</span>
            <span class="alert-message">${message}</span>
            <button class="alert-close" onclick="removeAlert(this.parentElement.parentElement)">
                <span class="material-icons">close</span>
            </button>
        </div>
    `;
    
    alert.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        max-width: 350px;
        padding: 16px;
        background: white;
        border-left: 4px solid ${colors[type]};
        border-radius: 8px;
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        animation: slideInRight 0.3s ease;
        font-family: inherit;
    `;
    
    return alert;
}

function removeAlert(alert) {
    alert.style.animation = 'slideOutRight 0.3s ease forwards';
    setTimeout(() => {
        if (alert.parentNode) {
            alert.parentNode.removeChild(alert);
        }
    }, 300);
}

// Mostrar toast
function showToast(message) {
    const toast = document.getElementById('loadingToast');
    const toastBody = toast.querySelector('.toast-body');
    
    toastBody.textContent = message;
    
    const bsToast = new bootstrap.Toast(toast, {
        delay: 3000
    });
    bsToast.show();
}

// Mostrar erro
function showError(message) {
    const container = document.getElementById('pdf-container');
    container.innerHTML = `
        <div style="text-align: center; color: var(--danger-color); padding: 40px;">
            <span class="material-icons" style="font-size: 48px; display: block; margin-bottom: 16px;">error_outline</span>
            <h5>Erro ao Carregar Documento</h5>
            <p>${message}</p>
            <button class="btn btn-primary mt-3" onclick="location.reload()">
                <span class="material-icons">refresh</span>
                Tentar Novamente
            </button>
        </div>
    `;
}

// Adicionar estilos para alertas
function addAlertStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .alert-notification .alert-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .alert-notification .material-icons {
            font-size: 20px;
        }
        
        .alert-notification .alert-message {
            flex-grow: 1;
            font-size: 14px;
            font-weight: 500;
        }
        
        .alert-notification .alert-close {
            background: none;
            border: none;
            cursor: pointer;
            padding: 4px;
            border-radius: 4px;
            opacity: 0.7;
            transition: opacity 0.2s;
        }
        
        .alert-notification .alert-close:hover {
            opacity: 1;
            background: rgba(0,0,0,0.1);
        }
        
        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOutRight {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
}

// Inicializar estilos
document.addEventListener('DOMContentLoaded', addAlertStyles);

// Debug functions (remover em produção)
function debugPDF() {
    console.log({
        pdfDoc: pdfDoc,
        currentPage: pageNum,
        totalPages: pdfDoc ? pdfDoc.numPages : 0,
        scale: scale,
        rotation: rotation,
        rendering: pageRendering
    });
}

// Função para carregar PDF customizado (para uso futuro)
function loadCustomPDF(url) {
    showLoading(true);
    
    pdfjsLib.getDocument(url).promise.then(function(pdfDoc_) {
        pdfDoc = pdfDoc_;
        pageNum = 1;
        updateDocumentInfo();
        renderPage(pageNum);
        showLoading(false);
        showAlert('Novo documento carregado com sucesso', 'success');
    }).catch(function(error) {
        console.error('Erro ao carregar PDF customizado:', error);
        showError('Erro ao carregar o documento solicitado');
        showLoading(false);
    });
}

// Carregar mais comentários
function loadMoreComments() {
    const loadButton = document.querySelector('.btn-load-more');
    const originalText = loadButton.innerHTML;
    
    loadButton.innerHTML = '<span class="material-icons rotating">sync</span> Carregando...';
    loadButton.disabled = true;
    
    // Simular carregamento
    setTimeout(() => {
        addMockComments();
        loadButton.innerHTML = originalText;
        loadButton.disabled = false;
    }, 1500);
}

// Adicionar comentários simulados
function addMockComments() {
    const mockComments = [
        {
            author: 'Ana Costa',
            avatar: 'A',
            time: '3 dias atrás',
            content: 'Muito bem explicado! Ajudou bastante na minha dissertação.',
            likes: 2
        },
        {
            author: 'João Silva',
            avatar: 'J',
            time: '1 semana atrás',
            content: 'Existe algum material complementar sobre integrais duplas?',
            likes: 0
        },
        {
            author: 'Dr. Santos',
            avatar: 'D',
            time: '1 semana atrás',
            content: 'Excelente referência para o curso de Cálculo II. Recomendo a todos os estudantes.',
            likes: 12
        }
    ];
    
    const commentsContainer = document.getElementById('comments-section');
    
    mockComments.forEach(comment => {
        const commentElement = document.createElement('div');
        commentElement.className = 'comment-item';
        commentElement.style.opacity = '0';
        
        commentElement.innerHTML = `
            <div class="comment-header">
                <div class="comment-author">
                    <div class="author-avatar">${comment.avatar}</div>
                    <span class="author-name">${comment.author}</span>
                </div>
                <span class="comment-time">${comment.time}</span>
            </div>
            <div class="comment-content">${comment.content}</div>
            <div class="comment-actions">
                <button class="btn-like" onclick="toggleLike(this)">
                    <span class="material-icons">thumb_up</span>
                    <span class="like-count">${comment.likes}</span>
                </button>
                <button class="btn-reply" onclick="replyToComment(this)">
                    <span class="material-icons">reply</span>
                    Responder
                </button>
            </div>
        `;
        
        commentsContainer.appendChild(commentElement);
        
        // Animar entrada
        setTimeout(() => {
            commentElement.style.transition = 'opacity 0.3s ease';
            commentElement.style.opacity = '1';
        }, 100);
    });
    
    showAlert('Mais comentários carregados', 'success');
}

// Pesquisar no documento (funcionalidade futura)
function searchInDocument(query) {
    if (!query.trim()) {
        showAlert('Digite algo para pesquisar', 'warning');
        return;
    }
    
    showAlert('Funcionalidade de pesquisa em desenvolvimento', 'info');
    // TODO: Implementar pesquisa no PDF
}

// Compartilhar documento
function shareDocument() {
    if (navigator.share) {
        navigator.share({
            title: 'Cálculo Diferencial e Integral',
            text: 'Confira este documento acadêmico no Academicoapp',
            url: window.location.href
        }).then(() => {
            showAlert('Link compartilhado com sucesso', 'success');
        }).catch(() => {
            fallbackShare();
        });
    } else {
        fallbackShare();
    }
}

// Compartilhamento alternativo
function fallbackShare() {
    const url = window.location.href;
    
    if (navigator.clipboard) {
        navigator.clipboard.writeText(url).then(() => {
            showAlert('Link copiado para a área de transferência', 'success');
        }).catch(() => {
            showManualCopyAlert(url);
        });
    } else {
        showManualCopyAlert(url);
    }
}

// Alerta para cópia manual
function showManualCopyAlert(url) {
    const alertDiv = document.createElement('div');
    alertDiv.innerHTML = `
        <div style="margin-bottom: 10px;">Copie o link abaixo:</div>
        <input type="text" value="${url}" style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px;" readonly onclick="this.select()">
    `;
    
    // Criar modal personalizado para mostrar o link
    showCustomModal('Compartilhar Documento', alertDiv.innerHTML);
}

// Modal customizado
function showCustomModal(title, content) {
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">${title}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
    
    // Remover modal após fechamento
    modal.addEventListener('hidden.bs.modal', function() {
        document.body.removeChild(modal);
    });
}

// Favoritar documento
function toggleFavorite() {
    // Simular toggle de favorito
    const isFavorited = localStorage.getItem('favorited_document') === 'true';
    const newState = !isFavorited;
    
    localStorage.setItem('favorited_document', newState.toString());
    
    if (newState) {
        showAlert('Documento adicionado aos favoritos', 'success');
    } else {
        showAlert('Documento removido dos favoritos', 'info');
    }
    
    // Atualizar ícone (se existir)
    const favoriteBtn = document.querySelector('.btn-favorite');
    if (favoriteBtn) {
        const icon = favoriteBtn.querySelector('.material-icons');
        icon.textContent = newState ? 'favorite' : 'favorite_border';
        favoriteBtn.classList.toggle('active', newState);
    }
}

// Reportar problema
function reportIssue() {
    const issues = [
        'Documento não carrega',
        'Qualidade da imagem ruim',
        'Páginas faltando',
        'Conteúdo inadequado',
        'Erro de copyright',
        'Outro problema'
    ];
    
    let optionsHTML = issues.map(issue => 
        `<label class="d-block mb-2">
            <input type="radio" name="issue" value="${issue}" class="me-2">
            ${issue}
        </label>`
    ).join('');
    
    optionsHTML += `
        <div class="mt-3">
            <label>Detalhes adicionais (opcional):</label>
            <textarea class="form-control mt-2" rows="3" placeholder="Descreva o problema em detalhes..."></textarea>
        </div>
    `;
    
    showCustomModal('Reportar Problema', optionsHTML);
}

// Configurações do visualizador
function showViewerSettings() {
    const settings = `
        <div class="settings-group">
            <h6>Preferências de Visualização</h6>
            <label class="d-block mb-2">
                <input type="checkbox" class="me-2" id="setting-dark-mode">
                Modo escuro
            </label>
            <label class="d-block mb-2">
                <input type="checkbox" class="me-2" id="setting-auto-scroll">
                Scroll automático
            </label>
            <label class="d-block mb-2">
                <input type="checkbox" class="me-2" id="setting-smooth-zoom">
                Zoom suave
            </label>
        </div>
        <div class="settings-group mt-4">
            <h6>Qualidade</h6>
            <select class="form-select" id="setting-quality">
                <option value="1">Baixa</option>
                <option value="1.5" selected>Média</option>
                <option value="2">Alta</option>
            </select>
        </div>
        <div class="mt-4">
            <button class="btn btn-primary" onclick="applySettings()">Aplicar Configurações</button>
        </div>
    `;
    
    showCustomModal('Configurações do Visualizador', settings);
}

// Aplicar configurações
function applySettings() {
    const darkMode = document.getElementById('setting-dark-mode')?.checked;
    const autoScroll = document.getElementById('setting-auto-scroll')?.checked;
    const smoothZoom = document.getElementById('setting-smooth-zoom')?.checked;
    const quality = document.getElementById('setting-quality')?.value;
    
    // Salvar configurações
    const settings = { darkMode, autoScroll, smoothZoom, quality };
    localStorage.setItem('viewer_settings', JSON.stringify(settings));
    
    // Aplicar configurações
    if (darkMode) {
        document.body.classList.add('dark-mode');
    } else {
        document.body.classList.remove('dark-mode');
    }
    
    if (quality && parseFloat(quality) !== scale) {
        scale = parseFloat(quality);
        updateZoom();
    }
    
    showAlert('Configurações aplicadas com sucesso', 'success');
    
    // Fechar modal
    const modal = bootstrap.Modal.getInstance(document.querySelector('.modal.show'));
    if (modal) modal.hide();
}

// Carregar configurações salvas
function loadSavedSettings() {
    try {
        const savedSettings = localStorage.getItem('viewer_settings');
        if (savedSettings) {
            const settings = JSON.parse(savedSettings);
            
            if (settings.darkMode) {
                document.body.classList.add('dark-mode');
            }
            
            if (settings.quality) {
                scale = parseFloat(settings.quality);
            }
        }
    } catch (error) {
        console.error('Erro ao carregar configurações:', error);
    }
}

// Estatísticas de uso (para analytics)
function trackUsage(action, details = {}) {
    const usage = {
        action: action,
        timestamp: new Date().toISOString(),
        page: pageNum,
        scale: scale,
        ...details
    };
    
    // Em produção, enviar para sistema de analytics
    console.log('Usage tracked:', usage);
}

// Adicionar estilos para animações
function addAnimationStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .rotating {
            animation: rotate 1s linear infinite;
        }
        
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .dark-mode {
            filter: invert(1) hue-rotate(180deg);
        }
        
        .dark-mode img,
        .dark-mode video,
        .dark-mode canvas {
            filter: invert(1) hue-rotate(180deg);
        }
    `;
    document.head.appendChild(style);
}

// Inicializar configurações e estilos adicionais
document.addEventListener('DOMContentLoaded', function() {
    loadSavedSettings();
    addAnimationStyles();
    
    // Registrar eventos de uso
    document.addEventListener('click', function(e) {
        if (e.target.matches('[onclick*="Page"]')) {
            trackUsage('navigation', { direction: e.target.textContent.toLowerCase() });
        } else if (e.target.matches('[onclick*="zoom"]')) {
            trackUsage('zoom', { type: e.target.textContent.toLowerCase() });
        }
    });
    
    // Adicionar event listener ao botão de carregar mais comentários
    const loadMoreBtn = document.querySelector('.btn-load-more');
    if (loadMoreBtn && !loadMoreBtn.onclick) {
        loadMoreBtn.onclick = loadMoreComments;
    }
});

// Verificar se é dispositivo móvel
function isMobile() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

// Ajustes específicos para mobile
function applyMobileOptimizations() {
    if (isMobile()) {
        // Ajustar escala inicial para mobile
        scale = 0.8;
        
        // Desabilitar zoom por pinch (pode interferir com zoom do PDF)
        document.addEventListener('touchmove', function(event) {
            if (event.scale !== 1) {
                event.preventDefault();
            }
        }, { passive: false });
        
        // Adicionar classe para estilos mobile
        document.body.classList.add('mobile-device');
        
        console.log('Otimizações mobile aplicadas');
    }
}

// Aplicar otimizações mobile na inicialização
document.addEventListener('DOMContentLoaded', applyMobileOptimizations);

// Função para cleanup (importante para SPAs)
function cleanup() {
    if (pdfDoc) {
        pdfDoc.destroy();
        pdfDoc = null;
    }
    
    // Remover event listeners
    document.removeEventListener('keydown', setupEventListeners);
    window.removeEventListener('resize', setupEventListeners);
    document.removeEventListener('fullscreenchange', setupEventListeners);
    
    console.log('Visualizador limpo e recursos liberados');
}