/**
 * Homepage Application - Academic Platform Landing Page
 * @author Academicoapp Team
 * @version 1.0.0
 */

// Main Application Module
const HomepageApp = (function() {
  'use strict';

  // Application State
  const state = {
    currentTheme: localStorage.getItem('theme') || 'light',
    isNavbarScrolled: false,
    formSubmitting: false,
    animations: {
      enabled: !window.matchMedia('(prefers-reduced-motion: reduce)').matches
    }
  };

  // DOM Elements Cache
  const elements = {};

  // Configuration
  const config = {
    scrollThreshold: 100,
    animationDuration: 300,
    toastDuration: 5000,
    heroImages: [
      'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
      'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
      'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80'
    ],
    heroImageInterval: 15000
  };

  /**
   * Initialize the application
   */
  function init() {
    cacheElements();
    initTheme();
    setupEventListeners();
    initScrollEffects();
    initAnimations();
    initHeroSlideshow();
    preloadImages();
    showWelcomeMessage();
  }

  /**
   * Cache DOM elements for better performance
   */
  function cacheElements() {
    elements.navbar = document.getElementById('mainNav');
    elements.themeToggle = document.getElementById('themeToggle');
    elements.contactForm = document.getElementById('contactForm');
    elements.toastContainer = document.getElementById('toastContainer');
    elements.heroBackground = document.querySelector('.hero-background');
    elements.navLinks = document.querySelectorAll('.nav-link[href^="#"]');
    elements.scrollElements = document.querySelectorAll('[data-scroll]');
    elements.serviceCards = document.querySelectorAll('.service-card');
    elements.teamCards = document.querySelectorAll('.team-card');
  }

  /**
   * Initialize theme system
   */
  function initTheme() {
    applyTheme(state.currentTheme);
    
    if (elements.themeToggle) {
      elements.themeToggle.addEventListener('click', toggleTheme);
      updateThemeToggleIcon();
    }
  }

  /**
   * Apply theme to document
   */
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    state.currentTheme = theme;
    localStorage.setItem('theme', theme);
    updateThemeToggleIcon();
  }

  /**
   * Toggle between light and dark themes
   */
  function toggleTheme() {
    const newTheme = state.currentTheme === 'light' ? 'dark' : 'light';
    applyTheme(newTheme);
    showToast(`Tema alterado para ${newTheme === 'dark' ? 'escuro' : 'claro'}`, 'info');
  }

  /**
   * Update theme toggle button icon
   */
  function updateThemeToggleIcon() {
    if (!elements.themeToggle) return;
    
    const icon = elements.themeToggle.querySelector('i');
    if (icon) {
      icon.className = state.currentTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
  }

  /**
   * Setup all event listeners
   */
  function setupEventListeners() {
    // Scroll events
    window.addEventListener('scroll', throttle(handleScroll, 16));
    
    // Navigation smooth scrolling
    elements.navLinks.forEach(link => {
      link.addEventListener('click', handleSmoothScroll);
    });

    // Contact form
    if (elements.contactForm) {
      elements.contactForm.addEventListener('submit', handleContactForm);
      setupFormValidation();
    }

    // Service cards hover effects
    elements.serviceCards.forEach(card => {
      card.addEventListener('mouseenter', handleServiceCardHover);
      card.addEventListener('mouseleave', handleServiceCardLeave);
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', handleKeyboardShortcuts);

    // Window resize handler
    window.addEventListener('resize', debounce(handleResize, 250));

    // Intersection Observer for animations
    if (state.animations.enabled) {
      initIntersectionObserver();
    }
  }

  /**
   * Handle scroll events
   */
  function handleScroll() {
    const scrollY = window.scrollY;
    
    // Navbar scroll effect
    if (scrollY > config.scrollThreshold && !state.isNavbarScrolled) {
      state.isNavbarScrolled = true;
      elements.navbar?.classList.add('scrolled');
    } else if (scrollY <= config.scrollThreshold && state.isNavbarScrolled) {
      state.isNavbarScrolled = false;
      elements.navbar?.classList.remove('scrolled');
    }

    // Parallax effects (only if animations are enabled)
    if (state.animations.enabled && elements.heroBackground) {
      const parallaxSpeed = scrollY * 0.5;
      elements.heroBackground.style.transform = `translateY(${parallaxSpeed}px)`;
    }
  }

  /**
   * Handle smooth scrolling for navigation links
   */
  function handleSmoothScroll(event) {
    event.preventDefault();
    
    const targetId = event.currentTarget.getAttribute('href');
    const targetElement = document.querySelector(targetId);
    
    if (targetElement) {
      const offsetTop = targetElement.offsetTop - (elements.navbar?.offsetHeight || 0);
      
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });

      // Close mobile menu if open
      const navbarCollapse = document.querySelector('.navbar-collapse');
      if (navbarCollapse?.classList.contains('show')) {
        const bsCollapse = new bootstrap.Collapse(navbarCollapse);
        bsCollapse.hide();
      }
    }
  }

  /**
   * Handle contact form submission
   */
  function handleContactForm(event) {
    event.preventDefault();
    
    if (state.formSubmitting) return;

    const formData = new FormData(event.target);
    const formObject = Object.fromEntries(formData);

    // Validate form
    if (!validateContactForm(formObject)) {
      return;
    }

    state.formSubmitting = true;
    showFormLoading(true);

    // Simulate form submission
    setTimeout(() => {
      submitContactForm(formObject)
        .then(() => {
          showToast('Mensagem enviada com sucesso! Retornaremos em breve.', 'success');
          resetContactForm();
        })
        .catch(() => {
          showToast('Erro ao enviar mensagem. Tente novamente.', 'error');
        })
        .finally(() => {
          state.formSubmitting = false;
          showFormLoading(false);
        });
    }, 2000);
  }

  /**
   * Validate contact form
   */
  function validateContactForm(data) {
    const errors = {};

    if (!data.name?.trim()) {
      errors.name = 'Nome é obrigatório';
    }

    if (!data.email?.trim()) {
      errors.email = 'Email é obrigatório';
    } else if (!isValidEmail(data.email)) {
      errors.email = 'Email inválido';
    }

    if (!data.message?.trim()) {
      errors.message = 'Mensagem é obrigatória';
    } else if (data.message.trim().length < 10) {
      errors.message = 'Mensagem muito curta (mínimo 10 caracteres)';
    }

    // Show validation errors
    Object.keys(errors).forEach(field => {
      showFieldError(field, errors[field]);
    });

    return Object.keys(errors).length === 0;
  }

  /**
   * Setup form validation
   */
  function setupFormValidation() {
    const inputs = elements.contactForm?.querySelectorAll('input, textarea');
    inputs?.forEach(input => {
      input.addEventListener('blur', () => validateField(input));
      input.addEventListener('input', () => clearFieldError(input));
    });
  }

  /**
   * Validate individual field
   */
  function validateField(input) {
    const value = input.value.trim();
    const field = input.id;
    
    switch (field) {
      case 'name':
        if (!value) {
          showFieldError(field, 'Nome é obrigatório');
          return false;
        }
        break;
      case 'email':
        if (!value) {
          showFieldError(field, 'Email é obrigatório');
          return false;
        } else if (!isValidEmail(value)) {
          showFieldError(field, 'Email inválido');
          return false;
        }
        break;
      case 'message':
        if (!value) {
          showFieldError(field, 'Mensagem é obrigatória');
          return false;
        } else if (value.length < 10) {
          showFieldError(field, 'Mensagem muito curta');
          return false;
        }
        break;
    }
    
    clearFieldError(input);
    return true;
  }

  /**
   * Show field validation error
   */
  function showFieldError(fieldName, message) {
    const field = document.getElementById(fieldName);
    const feedback = field?.parentNode.querySelector('.invalid-feedback');
    
    if (field && feedback) {
      field.classList.add('is-invalid');
      feedback.textContent = message;
    }
  }

  /**
   * Clear field validation error
   */
  function clearFieldError(field) {
    field.classList.remove('is-invalid');
    const feedback = field.parentNode.querySelector('.invalid-feedback');
    if (feedback) {
      feedback.textContent = '';
    }
  }

  /**
   * Show/hide form loading state
   */
  function showFormLoading(isLoading) {
    const submitBtn = elements.contactForm?.querySelector('button[type="submit"]');
    const buttonText = submitBtn?.querySelector('.button-text');
    const spinner = submitBtn?.querySelector('.loading-spinner');

    if (submitBtn && buttonText && spinner) {
      if (isLoading) {
        buttonText.textContent = 'Enviando...';
        spinner.classList.remove('d-none');
        submitBtn.disabled = true;
      } else {
        buttonText.textContent = 'Enviar Mensagem';
        spinner.classList.add('d-none');
        submitBtn.disabled = false;
      }
    }
  }

  /**
   * Submit contact form (simulation)
   */
  async function submitContactForm(data) {
    // Simulate API call
    return new Promise((resolve, reject) => {
      // Random success/failure for demo
      const success = Math.random() > 0.1; // 90% success rate
      
      if (success) {
        console.log('Contact form submitted:', data);
        resolve();
      } else {
        reject(new Error('Submission failed'));
      }
    });
  }

  /**
   * Reset contact form
   */
  function resetContactForm() {
    if (elements.contactForm) {
      elements.contactForm.reset();
      
      // Clear validation states
      const fields = elements.contactForm.querySelectorAll('.form-control');
      fields.forEach(field => clearFieldError(field));
    }
  }

  /**
   * Initialize hero slideshow
   */
  function initHeroSlideshow() {
    if (!elements.heroBackground || !state.animations.enabled) return;

    let currentImageIndex = 0;
    
    function changeBackgroundImage() {
      currentImageIndex = (currentImageIndex + 1) % config.heroImages.length;
      const newImage = config.heroImages[currentImageIndex];
      
      elements.heroBackground.style.backgroundImage = `url('${newImage}')`;
    }

    // Change image every interval
    setInterval(changeBackgroundImage, config.heroImageInterval);
  }

  /**
   * Preload images for better performance
   */
  function preloadImages() {
    config.heroImages.forEach(src => {
      const img = new Image();
      img.src = src;
    });
  }

  /**
   * Initialize scroll animations using Intersection Observer
   */
  function initIntersectionObserver() {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
      }
    );

    // Observe elements for animation
    const animateElements = document.querySelectorAll('.feature-card, .service-card, .team-card, .contact-item');
    animateElements.forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(30px)';
      observer.observe(el);
    });
  }

  /**
   * Initialize scroll effects and animations
   */
  function initScrollEffects() {
    // Add smooth scroll behavior
    document.documentElement.style.scrollBehavior = 'smooth';
  }

  /**
   * Initialize general animations
   */
  function initAnimations() {
    // Add CSS for animations
    const style = document.createElement('style');
    style.textContent = `
      .animate-in {
        opacity: 1 !important;
        transform: translateY(0) !important;
        transition: all 0.6s cubic-bezier(0.4, 0, 0.2, 1);
      }
    `;
    document.head.appendChild(style);
  }

  /**
   * Handle service card hover effects
   */
  function handleServiceCardHover(event) {
    const card = event.currentTarget;
    if (state.animations.enabled) {
      card.style.transform = 'translateY(-12px)';
    }
  }

  /**
   * Handle service card leave effects
   */
  function handleServiceCardLeave(event) {
    const card = event.currentTarget;
    if (state.animations.enabled) {
      card.style.transform = 'translateY(0)';
    }
  }

  /**
   * Handle keyboard shortcuts
   */
  function handleKeyboardShortcuts(event) {
    // Escape to close mobile menu
    if (event.key === 'Escape') {
      const navbarCollapse = document.querySelector('.navbar-collapse.show');
      if (navbarCollapse) {
        const bsCollapse = new bootstrap.Collapse(navbarCollapse);
        bsCollapse.hide();
      }
    }

    // Alt + T to toggle theme
    if (event.altKey && event.key === 't') {
      event.preventDefault();
      toggleTheme();
    }

    // Alt + C to focus contact form
    if (event.altKey && event.key === 'c') {
      event.preventDefault();
      const nameField = document.getElementById('name');
      if (nameField) {
        nameField.scrollIntoView({ behavior: 'smooth', block: 'center' });
        setTimeout(() => nameField.focus(), 300);
      }
    }
  }

  /**
   * Handle window resize
   */
  function handleResize() {
    // Update animations based on motion preferences
    state.animations.enabled = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    // Reset any inline styles that might interfere with responsive design
    if (window.innerWidth <= 768) {
      elements.serviceCards.forEach(card => {
        card.style.transform = '';
      });
    }
  }

  /**
   * Show toast notification
   */
  function showToast(message, type = 'info', duration = config.toastDuration) {
    if (!elements.toastContainer) return;

    const toastId = `toast-${Date.now()}`;
    const iconClass = {
      'success': 'fas fa-check-circle',
      'error': 'fas fa-exclamation-circle',
      'warning': 'fas fa-exclamation-triangle',
      'info': 'fas fa-info-circle'
    }[type] || 'fas fa-info-circle';

    const toast = document.createElement('div');
    toast.id = toastId;
    toast.className = `toast toast-${type}`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
      <div class="toast-body d-flex align-items-center">
        <i class="${iconClass} me-2"></i>
        <span class="flex-grow-1">${message}</span>
        <button type="button" class="btn-close ms-2" onclick="HomepageApp.removeToast('${toastId}')" aria-label="Fechar"></button>
      </div>
    `;
    
    elements.toastContainer.appendChild(toast);
    
    // Animate in
    requestAnimationFrame(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      toast.style.transition = 'all 0.3s ease';
      
      requestAnimationFrame(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateX(0)';
      });
    });
    
    // Auto remove
    setTimeout(() => {
      removeToast(toastId);
    }, duration);
  }

  /**
   * Remove toast notification
   */
  function removeToast(toastId) {
    const toast = document.getElementById(toastId);
    if (toast) {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(100%)';
      setTimeout(() => toast.remove(), 300);
    }
  }

  /**
   * Show welcome message
   */
  function showWelcomeMessage() {
    setTimeout(() => {
      showToast('Bem-vindo ao Academicoapp! Explore nossa plataforma educacional.', 'success');
    }, 1000);
  }

  /**
   * Utility functions
   */

  /**
   * Email validation
   */
  function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Throttle function to limit function calls
   */
  function throttle(func, limit) {
    let inThrottle;
    return function() {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }

  /**
   * Debounce function to delay function calls
   */
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func.apply(this, args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  /**
   * Analytics tracking (placeholder)
   */
  function trackEvent(eventName, data = {}) {
    // Placeholder for analytics tracking
    console.log('Event:', eventName, data);
    
    // Example: Google Analytics 4
    // if (typeof gtag !== 'undefined') {
    //   gtag('event', eventName, data);
    // }
  }

  /**
   * Error handling
   */
  function handleError(error, context = 'Unknown') {
    console.error(`Error in ${context}:`, error);
    
    // Show user-friendly error message
    showToast('Ocorreu um erro inesperado. Tente recarregar a página.', 'error');
    
    // Track error for monitoring
    trackEvent('error', {
      context: context,
      message: error.message,
      stack: error.stack
    });
  }

  /**
   * Performance monitoring
   */
  function initPerformanceMonitoring() {
    // Monitor page load performance
    window.addEventListener('load', () => {
      if (window.performance && window.performance.timing) {
        const loadTime = window.performance.timing.loadEventEnd - window.performance.timing.navigationStart;
        trackEvent('page_load', { loadTime: loadTime });
        console.log(`Page loaded in ${loadTime}ms`);
      }
    });

    // Monitor Core Web Vitals
    if ('PerformanceObserver' in window) {
      // Largest Contentful Paint
      new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          trackEvent('lcp', { value: entry.startTime });
        }
      }).observe({ entryTypes: ['largest-contentful-paint'] });

      // First Input Delay
      new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          trackEvent('fid', { value: entry.processingStart - entry.startTime });
        }
      }).observe({ entryTypes: ['first-input'] });
    }
  }

  // Public API
  return {
    init,
    toggleTheme,
    showToast,
    removeToast,
    trackEvent
  };

})();

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', HomepageApp.init);

// Handle page visibility changes
document.addEventListener('visibilitychange', function() {
  if (document.visibilityState === 'visible') {
    console.log('Page became visible');
    HomepageApp.trackEvent('page_visible');
  }
});

// Service Worker registration (for offline functionality)
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function() {
    navigator.serviceWorker.register('/sw.js')
      .then(function(registration) {
        console.log('ServiceWorker registration successful');
        HomepageApp.trackEvent('service_worker_registered');
      })
      .catch(function(err) {
        console.log('ServiceWorker registration failed:', err);
      });
  });
}

// Handle unhandled promise rejections
window.addEventListener('unhandledrejection', function(event) {
  console.error('Unhandled promise rejection:', event.reason);
  HomepageApp.trackEvent('unhandled_rejection', { reason: event.reason });
});

// Handle JavaScript errors
window.addEventListener('error', function(event) {
  console.error('JavaScript error:', event.error);
  HomepageApp.trackEvent('javascript_error', {
    message: event.message,
    filename: event.filename,
    lineno: event.lineno
  });
});